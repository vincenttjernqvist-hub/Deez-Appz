import importlib.util
import hashlib
import json
import os
import platform
import pwd
import queue
import signal
import selectors
import shutil
import subprocess
import sys
import tarfile
import tempfile
import threading
import urllib.error
import urllib.parse
import urllib.request
from pathlib import PurePosixPath

if importlib.util.find_spec("tkinter") is None:
    if shutil.which("apt-get") is None:
        sys.exit("Tkinter is missing and this system does not use Ubuntu's package manager.")

    print("Tkinter is missing. Installing it...")
    subprocess.run(["pkexec", "apt-get", "update"], check=True)
    subprocess.run(
        ["pkexec", "apt-get", "install", "-y", "python3-tk"],
        check=True
    )

import tkinter as tk
from tkinter import font as tkfont
from tkinter import messagebox, ttk

root = tk.Tk()
root.title("Deez Appz")
root.geometry("1000x760")
root.minsize(640, 480)
root.configure(bg="#78B9F2")

app_canvas = tk.Canvas(root, bg="#78B9F2", highlightthickness=0)
app_scrollbar = ttk.Scrollbar(
    root,
    orient="vertical",
    command=app_canvas.yview,
)
app_canvas.configure(yscrollcommand=app_scrollbar.set)
app_scrollbar.pack(side="right", fill="y")
app_canvas.pack(side="left", fill="both", expand=True)
app_content = tk.Frame(app_canvas, bg="#78B9F2")
app_content_window = app_canvas.create_window(
    (0, 0),
    window=app_content,
    anchor="nw",
)


def update_scroll_region(_event=None):
    app_canvas.configure(scrollregion=app_canvas.bbox("all"))


def resize_app_content(event):
    app_canvas.itemconfigure(app_content_window, width=event.width)


def scroll_app(event):
    if event.num == 4:
        app_canvas.yview_scroll(-1, "units")
    elif event.num == 5:
        app_canvas.yview_scroll(1, "units")
    elif event.delta:
        app_canvas.yview_scroll(int(-event.delta / 120), "units")


app_content.bind("<Configure>", update_scroll_region)
app_canvas.bind("<Configure>", resize_app_content)
app_canvas.bind_all("<MouseWheel>", scroll_app)
app_canvas.bind_all("<Button-4>", scroll_app)
app_canvas.bind_all("<Button-5>", scroll_app)

app_icon_path = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "assets",
    "app-icon.png",
)
app_icon = tk.PhotoImage(file=app_icon_path)
root.iconphoto(True, app_icon)


MANUAL_INSTALLER_APPS = {
    "Google Chrome",
    "Bauh",
    "Topgrade",
    "AppImageLauncher",
    "Pacstall",
    "Homebrew",
    "JetBrains Toolbox",
}


def split_install_targets(selected_apps):
    """Identify apps that need custom setup around the privileged batch."""
    batch_apps = []
    manual_apps = []
    seen = set()

    for app_name in selected_apps:
        if app_name in seen:
            continue
        seen.add(app_name)
        if app_name in MANUAL_INSTALLER_APPS:
            manual_apps.append(app_name)
        else:
            batch_apps.append(app_name)

    return batch_apps, manual_apps


def set_status(message):
    status_text.configure(state="normal")
    status_text.delete("1.0", "end")
    status_text.insert("end", message)
    display_line_counts = status_text.count(
        "1.0",
        "end-1c",
        "update",
        "displaylines",
    )
    if isinstance(display_line_counts, tuple):
        display_lines = display_line_counts[0] + 1
    elif isinstance(display_line_counts, int):
        display_lines = display_line_counts + 1
    else:
        display_lines = message.count("\n") + 1
    status_text.configure(height=max(5, display_lines))
    progress_height = (
        install_progress.winfo_reqheight() + 6
        if install_progress.winfo_manager()
        else 0
    )
    status_frame.configure(
        height=max(
            152,
            status_text.winfo_reqheight() + 16 + progress_height,
        )
    )
    status_text.see("end")
    status_text.configure(state="disabled")


install_progress_queue = queue.Queue()
install_worker_latest_progress = None
install_worker_progress_value = 0.0
installation_pause_event = threading.Event()
installation_pause_event.set()
installation_process_group = None
installation_process_lock = threading.Lock()
installation_active = False


def wait_if_installation_paused():
    installation_pause_event.wait()


def set_installation_process_group(process):
    global installation_process_group

    with installation_process_lock:
        installation_process_group = process.pid
        if not installation_pause_event.is_set():
            try:
                os.killpg(process.pid, signal.SIGSTOP)
            except ProcessLookupError:
                installation_process_group = None


def clear_installation_process_group(process):
    global installation_process_group

    with installation_process_lock:
        if installation_process_group != process.pid:
            return
        if not installation_pause_event.is_set():
            try:
                os.killpg(process.pid, signal.SIGCONT)
            except ProcessLookupError:
                pass
        installation_process_group = None


def run_install_command(command, check=True, **options):
    wait_if_installation_paused()
    capture_output = options.pop("capture_output", False)
    text = options.pop("text", False)
    input_data = options.pop("input", None)
    if capture_output:
        options["stdout"] = subprocess.PIPE
        options["stderr"] = subprocess.PIPE
    if input_data is not None:
        options["stdin"] = subprocess.PIPE

    process = subprocess.Popen(
        command,
        start_new_session=True,
        text=text,
        **options,
    )
    set_installation_process_group(process)
    try:
        stdout, stderr = process.communicate(input=input_data)
    finally:
        clear_installation_process_group(process)
    result = subprocess.CompletedProcess(
        command,
        process.returncode,
        stdout,
        stderr,
    )
    if check and result.returncode:
        raise subprocess.CalledProcessError(
            result.returncode,
            command,
            output=result.stdout,
            stderr=result.stderr,
        )
    return result


def read_install_worker_output(worker_process, on_progress=None):
    worker_stdout = bytearray()
    worker_errors = []
    pending_stderr = bytearray()

    def process_stderr_line(line):
        decoded_line = line.decode("utf-8", errors="replace").rstrip()
        if not decoded_line:
            return
        if not decoded_line.startswith("DEEZ_PROGRESS "):
            worker_errors.append(decoded_line)
            return
        try:
            progress_event = json.loads(
                decoded_line[len("DEEZ_PROGRESS "):],
            )
        except json.JSONDecodeError:
            worker_errors.append(decoded_line)
            return
        if isinstance(progress_event, dict):
            if on_progress is not None:
                on_progress(progress_event)
        else:
            worker_errors.append(decoded_line)

    with selectors.DefaultSelector() as selector:
        selector.register(
            worker_process.stdout,
            selectors.EVENT_READ,
            "stdout",
        )
        selector.register(
            worker_process.stderr,
            selectors.EVENT_READ,
            "stderr",
        )
        while selector.get_map():
            for key, _ in selector.select():
                chunk = os.read(key.fd, 4096)
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                if key.data == "stdout":
                    worker_stdout.extend(chunk)
                    continue
                pending_stderr.extend(chunk)
                while b"\n" in pending_stderr:
                    line, remainder = pending_stderr.split(b"\n", 1)
                    pending_stderr = bytearray(remainder)
                    process_stderr_line(line)

    if pending_stderr:
        process_stderr_line(pending_stderr)
    return (
        worker_stdout.decode("utf-8", errors="replace"),
        worker_errors,
        worker_process.wait(),
    )


def jetbrains_toolbox_release_urls(machine):
    download_key = {
        "x86_64": "linux",
        "aarch64": "linuxARM64",
    }.get(machine)
    if not download_key:
        raise ValueError(
            f"JetBrains Toolbox does not provide a Linux release for {machine}."
        )

    api_url = (
        "https://data.services.jetbrains.com/products/releases"
        "?code=TBA&latest=true&type=release"
    )
    with urllib.request.urlopen(api_url, timeout=30) as response:
        release_data = json.load(response)
    release = release_data["TBA"][0]
    download = release["downloads"][download_key]
    archive_url = download["link"]
    checksum_url = download["checksumLink"]
    for url in (archive_url, checksum_url):
        parsed_url = urllib.parse.urlparse(url)
        if (
            parsed_url.scheme != "https"
            or parsed_url.hostname != "download.jetbrains.com"
        ):
            raise ValueError("JetBrains returned an unexpected download host.")
    return archive_url, checksum_url


def verify_sha256_file(file_path, checksum_url):
    with urllib.request.urlopen(checksum_url, timeout=30) as response:
        checksum_parts = response.read(4096).decode("ascii").split()
    if not checksum_parts:
        raise ValueError("JetBrains returned an empty SHA-256 checksum.")
    expected_hash = checksum_parts[0].lower()
    if (
        len(expected_hash) != 64
        or any(character not in "0123456789abcdef" for character in expected_hash)
    ):
        raise ValueError("JetBrains returned an invalid SHA-256 checksum.")

    actual_hash = hashlib.sha256()
    with open(file_path, "rb") as downloaded_file:
        while chunk := downloaded_file.read(1024 * 1024):
            actual_hash.update(chunk)
    if actual_hash.hexdigest() != expected_hash:
        raise ValueError("The JetBrains Toolbox download failed checksum validation.")


def launch_jetbrains_toolbox(archive_path):
    install_dir = os.path.join(
        os.path.expanduser("~"),
        ".local",
        "share",
        "deez-appz",
        "jetbrains-toolbox-bootstrap",
    )
    os.makedirs(install_dir, mode=0o700, exist_ok=True)
    if os.path.islink(install_dir):
        raise ValueError("Refusing to install JetBrains Toolbox through a symlink.")
    install_root = os.path.realpath(install_dir)
    launcher_path = None

    with tarfile.open(archive_path, "r:gz") as archive:
        for member in archive.getmembers():
            relative_path = PurePosixPath(member.name)
            if relative_path.is_absolute() or ".." in relative_path.parts:
                raise ValueError(
                    "The JetBrains Toolbox archive contains an unsafe path."
                )
            parts = tuple(
                part for part in relative_path.parts if part not in ("", ".")
            )
            if not parts:
                continue
            destination = os.path.join(install_root, *parts)
            if os.path.commonpath((install_root, destination)) != install_root:
                raise ValueError(
                    "The JetBrains Toolbox archive contains an unsafe path."
                )
            parent_path = install_root
            for part in parts[:-1]:
                parent_path = os.path.join(parent_path, part)
                if os.path.islink(parent_path):
                    raise ValueError(
                        "Refusing to extract JetBrains Toolbox through a symlink."
                    )
            if member.isdir():
                os.makedirs(destination, mode=0o755, exist_ok=True)
                continue
            if not member.isfile():
                raise ValueError(
                    "The JetBrains Toolbox archive contains an unsupported entry."
                )

            os.makedirs(os.path.dirname(destination), mode=0o755, exist_ok=True)
            if os.path.islink(destination):
                raise ValueError(
                    "Refusing to overwrite a symbolic link while installing "
                    "JetBrains Toolbox."
                )
            source = archive.extractfile(member)
            if source is None:
                raise ValueError(
                    "The JetBrains Toolbox archive contains an unreadable file."
                )
            with source, open(destination, "wb") as target:
                shutil.copyfileobj(source, target)
            os.chmod(destination, member.mode & 0o755)
            if parts[-1] == "jetbrains-toolbox":
                launcher_path = destination

    if launcher_path is None:
        raise ValueError("The JetBrains Toolbox launcher was not found in the archive.")

    with tempfile.TemporaryFile() as output:
        process = subprocess.Popen(
            [launcher_path],
            cwd=os.path.dirname(launcher_path),
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            returncode = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            return "started; finish the initial setup in the Toolbox window"
        if returncode:
            output.seek(0)
            detail = output.read().decode("utf-8", errors="replace").strip()
            raise subprocess.CalledProcessError(
                returncode,
                [launcher_path],
                output=detail or "JetBrains Toolbox exited during startup.",
            )
    return "started successfully"


def toggle_installation_pause():
    global installation_process_group

    if not installation_active:
        return
    if installation_pause_event.is_set():
        installation_pause_event.clear()
        with installation_process_lock:
            process_group = installation_process_group
            if process_group is not None:
                try:
                    os.killpg(process_group, signal.SIGSTOP)
                except ProcessLookupError:
                    installation_process_group = None
        pause_install_button.set_label("Resume installation")
        set_status("Installation paused. Select Resume installation to continue.")
    else:
        installation_pause_event.set()
        with installation_process_lock:
            process_group = installation_process_group
            if process_group is not None:
                try:
                    os.killpg(process_group, signal.SIGCONT)
                except ProcessLookupError:
                    installation_process_group = None
        pause_install_button.set_label("Pause installation")
        set_status("Resuming installation...")


def show_worker_progress(progress):
    global install_worker_latest_progress, install_worker_progress_value

    if progress.get("event") == "started":
        install_worker_progress_value = 0.0
    if "completed" not in progress and install_worker_latest_progress:
        progress = {**install_worker_latest_progress, **progress}
    install_worker_latest_progress = progress

    completed = progress.get("completed", 0)
    total = progress.get("total", 0)
    progress_value = completed
    if progress.get("batch_count") and progress.get("percent") is not None:
        batch_fraction = progress["percent"] / 100
        if progress.get("stage") == "download":
            batch_fraction *= 0.5
        elif progress.get("stage") == "install":
            batch_fraction = 0.5 + batch_fraction * 0.5
        progress_value += progress["batch_count"] * batch_fraction
    install_worker_progress_value = min(
        total,
        max(install_worker_progress_value, progress_value),
    )
    percentage = (
        int(install_worker_progress_value * 100 / total)
        if total
        else 0
    )
    install_progress.stop()
    install_progress.configure(
        mode="determinate",
        maximum=max(total, 1),
        value=install_worker_progress_value,
    )

    phase = progress.get("message")
    if not phase and progress.get("app"):
        phase = f"Completed {progress['app']}"
    if not phase:
        phase = "Installation started"
    set_status(
        f"Installing apps: {percentage}% ({completed}/{total})\n"
        f"{phase}"
    )


def poll_install_progress():
    global installation_active

    try:
        while True:
            event, message = install_progress_queue.get_nowait()
            if event == "status":
                install_progress.stop()
                install_progress.configure(mode="indeterminate")
                install_progress.start(12)
                if installation_pause_event.is_set():
                    set_status(message)
                else:
                    set_status(
                        "Installation paused. "
                        "Select Resume installation to continue."
                    )
                continue
            if event == "download_start":
                app_name, total_bytes = message
                install_progress.stop()
                if total_bytes:
                    install_progress.configure(
                        mode="determinate",
                        maximum=100,
                        value=0,
                    )
                    if installation_pause_event.is_set():
                        set_status(f"Downloading {app_name}: 0%")
                else:
                    install_progress.configure(mode="indeterminate")
                    install_progress.start(12)
                    if installation_pause_event.is_set():
                        set_status(f"Downloading {app_name}...")
                continue
            if event == "worker_progress":
                if installation_pause_event.is_set():
                    show_worker_progress(message)
                continue
            if event == "download_progress":
                app_name, received_bytes, total_bytes = message
                percentage = min(100, int(received_bytes * 100 / total_bytes))
                install_progress.configure(value=percentage)
                if installation_pause_event.is_set():
                    set_status(f"Downloading {app_name}: {percentage}%")
                if percentage == 100:
                    root.after(250, poll_install_progress)
                    return
                continue

            install_progress.stop()
            install_progress.pack_forget()
            install_button.set_enabled(True)
            uninstall_button.set_enabled(True)
            installation_active = False
            installation_pause_event.set()
            pause_install_button.set_label("Pause installation")
            pause_install_button.set_enabled(False)
            set_status(message)
            return
    except queue.Empty:
        root.after(100, poll_install_progress)


def run_installation(selected_apps):
    try:
        result_message = perform_install_selected_apps(selected_apps)
    except Exception as error:
        result_message = f"Installation failed unexpectedly ({error})"
    finally:
        installation_pause_event.set()
    install_progress_queue.put(("done", result_message))


def uninstall_deez_app():
    try:
        package_status = subprocess.run(
            [
                "dpkg-query",
                "-W",
                "-f=${db:Status-Abbrev}",
                "deez-appz",
            ],
            check=False,
            capture_output=True,
            text=True,
        )
    except OSError as error:
        messagebox.showerror(
            "Unable to check installation",
            f"Could not check whether Deez Appz is installed: {error}",
            parent=root,
        )
        return

    if package_status.returncode != 0 or not package_status.stdout.startswith("ii "):
        messagebox.showinfo(
            "Deez Appz is not installed as a package",
            "This copy of Deez Appz was not installed as a Debian package, "
            "so it cannot remove itself safely. No files were changed.",
            parent=root,
        )
        return

    if not messagebox.askyesno(
        "Uninstall Deez Appz",
        "Remove Deez Appz from this computer? The app will close after "
        "uninstallation. Your project files and downloaded app packages "
        "will not be removed.",
        parent=root,
    ):
        return

    set_status("Uninstalling Deez Appz...")
    root.update_idletasks()
    try:
        subprocess.run(
            ["pkexec", "apt-get", "remove", "-y", "deez-appz"],
            check=True,
        )
    except (OSError, subprocess.CalledProcessError) as error:
        set_status(f"Could not uninstall Deez Appz ({error})")
        messagebox.showerror(
            "Uninstallation failed",
            f"Deez Appz could not be uninstalled: {error}",
            parent=root,
        )
        return

    root.destroy()


def install_selected_apps():
    global installation_active

    global install_worker_latest_progress
    global install_worker_progress_value
    selected_apps = [
        app_name for app_name, selected in app_selections.items()
        if selected.get()
    ]
    if not selected_apps:
        set_status("Select at least one app to install.")
        return

    installation_active = True
    installation_pause_event.set()
    pause_install_button.set_label("Pause installation")
    pause_install_button.set_enabled(True)
    install_button.set_enabled(False)
    uninstall_button.set_enabled(False)
    install_worker_latest_progress = None
    install_worker_progress_value = 0.0
    install_progress.pack(fill="x", pady=(6, 0))
    install_progress.start(12)
    set_status("Preparing installation...")
    threading.Thread(
        target=run_installation,
        args=(selected_apps,),
        daemon=True,
    ).start()
    root.after(100, poll_install_progress)


def perform_install_selected_apps(selected_apps):
    _, selected_manual_apps = split_install_targets(selected_apps)
    results = {}

    with tempfile.TemporaryDirectory(prefix="deez-appz-install-") as temp_dir:
        manual_paths = {}
        download_urls = {
            "Google Chrome": (
                "google_chrome_deb",
                "https://dl.google.com/linux/direct/"
                "google-chrome-stable_current_amd64.deb",
            ),
            "Pacstall": (
                "pacstall_installer",
                "https://pacstall.dev/q/install",
            ),
            "Homebrew": (
                "homebrew_installer",
                "https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh",
            ),
        }
        jetbrains_checksum_urls = {}
        if "JetBrains Toolbox" in selected_manual_apps:
            try:
                (
                    jetbrains_archive_url,
                    jetbrains_checksum_url,
                ) = jetbrains_toolbox_release_urls(platform.machine())
                download_urls["JetBrains Toolbox"] = (
                    "jetbrains_toolbox_archive",
                    jetbrains_archive_url,
                )
                jetbrains_checksum_urls["jetbrains_toolbox_archive"] = (
                    jetbrains_checksum_url
                )
            except (
                OSError,
                ValueError,
                KeyError,
                IndexError,
                TypeError,
            ) as error:
                results["JetBrains Toolbox"] = (
                    f"installation failed ({error})"
                )
        appimage_arch = {
            "x86_64": "x86_64",
            "aarch64": "aarch64",
            "armv7l": "armhf",
        }.get(platform.machine())
        if "AppImageLauncher" in selected_manual_apps:
            if appimage_arch is None:
                results["AppImageLauncher"] = (
                    "installation failed (unsupported CPU architecture)"
                )
            else:
                download_urls["AppImageLauncher"] = (
                    "appimagelauncher_lite",
                    "https://github.com/TheAssassin/AppImageLauncher/releases/"
                    "download/v3.0.0-beta-3/"
                    f"appimagelauncher-lite-3.0.0-beta-2-gha287-{appimage_arch}.AppImage",
                )
        for app_name in selected_manual_apps:
            if app_name not in download_urls:
                continue
            wait_if_installation_paused()
            key, url = download_urls[app_name]
            file_name = (
                "google_chrome.deb"
                if app_name == "Google Chrome"
                else key
            )
            file_path = os.path.join(temp_dir, file_name)
            try:
                with urllib.request.urlopen(url, timeout=60) as response:
                    try:
                        total_bytes = int(response.headers.get("Content-Length", "0"))
                    except ValueError:
                        total_bytes = 0
                    install_progress_queue.put((
                        "download_start",
                        (app_name, total_bytes),
                    ))
                    with open(file_path, "wb") as downloaded_file:
                        received_bytes = 0
                        last_percentage = -1
                        while True:
                            wait_if_installation_paused()
                            chunk = response.read(64 * 1024)
                            if not chunk:
                                break
                            downloaded_file.write(chunk)
                            received_bytes += len(chunk)
                            if total_bytes:
                                percentage = min(
                                    100,
                                    int(received_bytes * 100 / total_bytes),
                                )
                                if percentage != last_percentage:
                                    install_progress_queue.put((
                                        "download_progress",
                                        (app_name, received_bytes, total_bytes),
                                    ))
                                    last_percentage = percentage
                    if total_bytes:
                        install_progress_queue.put((
                            "download_progress",
                            (app_name, total_bytes, total_bytes),
                        ))
                manual_paths[key] = file_path
            except (OSError, urllib.error.URLError) as error:
                results[app_name] = f"installation failed ({error})"

        for key, checksum_url in jetbrains_checksum_urls.items():
            if key not in manual_paths:
                continue
            try:
                verify_sha256_file(manual_paths[key], checksum_url)
            except (
                OSError,
                urllib.error.URLError,
                UnicodeDecodeError,
                ValueError,
            ) as error:
                results["JetBrains Toolbox"] = (
                    f"installation failed ({error})"
                )
                manual_paths.pop(key, None)

        worker_apps = [
            app_name for app_name in selected_apps
            if app_name not in results and app_name != "AppImageLauncher"
        ]
        if worker_apps or "AppImageLauncher" in selected_manual_apps:
            install_progress_queue.put(("status", "Starting app installation..."))
            worker_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "install_worker.py",
            )
            request_path = os.path.join(temp_dir, "install-request.json")
            user = pwd.getpwuid(os.getuid())
            request = {
                "apps": worker_apps,
                "manual_install_data": {
                    "paths": manual_paths,
                    "uid": user.pw_uid,
                    "gid": user.pw_gid,
                    "progress_total": len(worker_apps) + int(
                        "appimagelauncher_lite" in manual_paths
                    ),
                    "remove_deprecated_appimagelauncher_ppa": (
                        "AppImageLauncher" in selected_manual_apps
                    ),
                },
            }
            with open(request_path, "w", encoding="utf-8") as request_file:
                json.dump(request, request_file)

            worker_progress_completed = 0
            worker_progress_total = request["manual_install_data"]["progress_total"]
            external_progress_completed = set()

            def report_external_completion(app_name):
                if app_name in external_progress_completed:
                    return
                external_progress_completed.add(app_name)
                install_progress_queue.put((
                    "worker_progress",
                    {
                        "event": "app_complete",
                        "app": app_name,
                        "completed": worker_progress_completed + len(external_progress_completed),
                        "total": worker_progress_total,
                    },
                ))

            def report_worker_progress(progress_event):
                nonlocal worker_progress_completed, worker_progress_total
                worker_progress_completed = progress_event.get(
                    "completed",
                    worker_progress_completed,
                )
                worker_progress_total = progress_event.get(
                    "total",
                    worker_progress_total,
                )
                install_progress_queue.put((
                    "worker_progress",
                    progress_event,
                ))

            try:
                wait_if_installation_paused()
                worker_command = [
                    "pkexec",
                    sys.executable,
                    worker_path,
                    "--request-file",
                    request_path,
                ]
                worker_process = subprocess.Popen(
                    worker_command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                    start_new_session=True,
                )
                set_installation_process_group(worker_process)
                try:
                    (
                        worker_stdout,
                        worker_errors,
                        worker_returncode,
                    ) = read_install_worker_output(
                        worker_process,
                        on_progress=report_worker_progress,
                    )
                finally:
                    clear_installation_process_group(worker_process)
                if worker_returncode:
                    raise subprocess.CalledProcessError(
                        worker_returncode,
                        worker_command,
                        output=worker_stdout,
                        stderr="\n".join(worker_errors),
                    )
                worker_results = json.loads(worker_stdout)
                maintenance_results = worker_results.pop("__maintenance__", {})
                results.update(worker_results)
                ppa_cleanup = maintenance_results.get("appimagelauncher_ppa")
                if ppa_cleanup and ppa_cleanup != "removed":
                    results["AppImageLauncher"] = (
                        f"warning: {ppa_cleanup}"
                    )
            except (
                OSError,
                subprocess.CalledProcessError,
                json.JSONDecodeError,
                KeyError,
            ) as error:
                results.update({
                    app_name: f"installation failed ({error})"
                    for app_name in worker_apps
                })
                if "AppImageLauncher" in selected_manual_apps:
                    results["AppImageLauncher"] = (
                        f"warning: could not clean up its old apt source ({error})"
                    )

        user_setup_commands = {
            "Bauh": ["pipx", "install", "--system-site-packages", "bauh"],
            "Topgrade": ["cargo", "install", "--locked", "topgrade"],
        }
        for app_name, command in user_setup_commands.items():
            if results.get(app_name) != "ready for user setup":
                continue
            try:
                install_progress_queue.put((
                    "worker_progress",
                    {"event": "phase", "message": f"Setting up {app_name}..."},
                ))
                run_install_command(command)
                results[app_name] = "installed"
            except (OSError, subprocess.CalledProcessError) as error:
                results[app_name] = f"installation failed ({error})"
            if "report_external_completion" in locals():
                report_external_completion(app_name)

        if results.get("Homebrew") == "ready for user setup":
            try:
                install_progress_queue.put((
                    "worker_progress",
                    {"event": "phase", "message": "Setting up Homebrew..."},
                ))
                run_install_command(
                    ["/bin/bash", manual_paths["homebrew_installer"]],
                    env={**os.environ, "NONINTERACTIVE": "1"},
                )
                results["Homebrew"] = "installed"
            except (KeyError, OSError, subprocess.CalledProcessError) as error:
                results["Homebrew"] = f"installation failed ({error})"
            if "report_external_completion" in locals():
                report_external_completion("Homebrew")

        if results.get("JetBrains Toolbox") == "ready for user setup":
            try:
                install_progress_queue.put((
                    "worker_progress",
                    {
                        "event": "phase",
                        "message": "Setting up JetBrains Toolbox...",
                    },
                ))
                results["JetBrains Toolbox"] = launch_jetbrains_toolbox(
                    manual_paths["jetbrains_toolbox_archive"]
                )
            except (
                KeyError,
                OSError,
                ValueError,
                tarfile.TarError,
                subprocess.CalledProcessError,
            ) as error:
                detail = getattr(error, "output", None) or str(error)
                results["JetBrains Toolbox"] = (
                    f"installation failed ({detail})"
                )
            if "report_external_completion" in locals():
                report_external_completion("JetBrains Toolbox")

        if (
            "AppImageLauncher" in selected_manual_apps
            and "appimagelauncher_lite" in manual_paths
            and results.get("AppImageLauncher") == "ready for user setup"
        ):
            appimage_path = manual_paths["appimagelauncher_lite"]
            try:
                install_progress_queue.put((
                    "worker_progress",
                    {"event": "phase", "message": "Setting up AppImageLauncher..."},
                ))
                os.chmod(appimage_path, 0o755)
                run_install_command(
                    [appimage_path, "install"],
                    capture_output=True,
                    text=True,
                )
                cleanup_warning = results.get("AppImageLauncher")
                results["AppImageLauncher"] = (
                    "installed for current user"
                    if not cleanup_warning
                    else f"installed for current user; {cleanup_warning}"
                )
            except (OSError, subprocess.CalledProcessError) as error:
                detail = (
                    getattr(error, "stderr", None)
                    or getattr(error, "output", None)
                    or str(error)
                ).strip()
                if (
                    isinstance(error, subprocess.CalledProcessError)
                    and error.returncode == 127
                    and not getattr(error, "stderr", None)
                    and not getattr(error, "output", None)
                ):
                    detail = (
                        "the AppImage runtime could not start; its libfuse2 "
                        "dependency may be unavailable"
                    )
                results["AppImageLauncher"] = (
                    f"installation failed ({detail})"
                )
            if "report_external_completion" in locals():
                report_external_completion("AppImageLauncher")
        elif (
            "AppImageLauncher" in selected_manual_apps
            and "AppImageLauncher" not in results
        ):
            results["AppImageLauncher"] = (
                "installation failed (system package setup did not provide "
                "the AppImage runtime dependency)"
            )

        if "report_external_completion" in locals():
            for app_name in (
                "Bauh",
                "Topgrade",
                "Homebrew",
                "JetBrains Toolbox",
            ):
                if app_name in worker_apps:
                    report_external_completion(app_name)

    return "\n".join(
        f"{app_name}: {results.get(app_name, 'installation failed (no result returned)')}"
        for app_name in selected_apps
    )


def uninstall_selected_apps():
    selected_apps = [
        app_name for app_name, selected in app_selections.items()
        if selected.get()
    ]
    if not selected_apps:
        set_status("Select at least one app to uninstall.")
        return
    if not messagebox.askyesno(
        "Confirm uninstall",
        "Uninstall the selected apps and remove their system configuration, "
        "user settings, and cache? Game libraries, saves, documents, and "
        "other personal content will be kept.",
        parent=root,
    ):
        return
    install_button.set_enabled(False)
    uninstall_button.set_enabled(False)
    install_progress.pack(fill="x", pady=(6, 0))
    install_progress.start(12)
    set_status("Uninstalling selected apps. This may take a few minutes...")
    threading.Thread(
        target=run_uninstallation,
        args=(selected_apps,),
        daemon=True,
    ).start()
    root.after(100, poll_install_progress)


def run_uninstallation(selected_apps):
    try:
        results = {}
        worker_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "install_worker.py",
        )
        with tempfile.TemporaryDirectory(
            prefix="deez-appz-uninstall-"
        ) as temp_dir:
            request_path = os.path.join(temp_dir, "uninstall-request.json")
            with open(request_path, "w", encoding="utf-8") as request_file:
                json.dump({
                    "apps": selected_apps,
                    "uid": os.getuid(),
                }, request_file)
            worker_command = [
                "pkexec",
                sys.executable,
                worker_path,
                "--uninstall-request-file",
                request_path,
            ]
            worker_process = subprocess.Popen(
                worker_command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=0,
            )
            worker_output = bytearray()
            worker_errors = []
            pending_stderr = bytearray()

            def process_worker_stderr_line(line):
                line = line.decode("utf-8", errors="replace").rstrip()
                if line.startswith("DEEZ_PROGRESS "):
                    try:
                        progress = json.loads(line[len("DEEZ_PROGRESS "):])
                        install_progress_queue.put((
                            "status",
                            progress["message"],
                        ))
                    except (json.JSONDecodeError, KeyError, TypeError):
                        worker_errors.append(line)
                elif line:
                    worker_errors.append(line)

            with selectors.DefaultSelector() as selector:
                selector.register(
                    worker_process.stdout,
                    selectors.EVENT_READ,
                    "stdout",
                )
                selector.register(
                    worker_process.stderr,
                    selectors.EVENT_READ,
                    "stderr",
                )
                while selector.get_map():
                    for key, _ in selector.select():
                        chunk = os.read(key.fd, 4096)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            continue
                        if key.data == "stdout":
                            worker_output.extend(chunk)
                            continue
                        pending_stderr.extend(chunk)
                        while b"\n" in pending_stderr:
                            line, remainder = pending_stderr.split(b"\n", 1)
                            pending_stderr = bytearray(remainder)
                            process_worker_stderr_line(line)
            if pending_stderr:
                process_worker_stderr_line(pending_stderr)
            worker_stdout = worker_output.decode("utf-8", errors="replace")
            worker_returncode = worker_process.wait()
            if worker_returncode:
                detail = "".join(worker_errors).strip()
                raise subprocess.CalledProcessError(
                    worker_returncode,
                    worker_command,
                    output=worker_stdout,
                    stderr=detail or "No error details were returned.",
                )
            worker_results = json.loads(worker_stdout)
            if not isinstance(worker_results, dict):
                raise ValueError("The uninstall worker returned invalid results.")
            results.update(worker_results)
        result_message = "\n".join(
            f"{app_name}: {results.get(app_name, 'uninstallation failed (no result returned)')}"
            for app_name in selected_apps
        )
    except (
        OSError,
        subprocess.CalledProcessError,
        json.JSONDecodeError,
        KeyError,
        TypeError,
        ValueError,
    ) as error:
        detail = getattr(error, "stderr", None) or getattr(error, "output", None)
        error_message = (
            detail.strip()
            if isinstance(detail, str) and detail.strip()
            else str(error)
        )
        result_message = "\n".join(
            f"{app_name}: uninstallation failed ({error_message})"
            for app_name in selected_apps
        )
    install_progress_queue.put(("done", result_message))


app_categories = {
    "Webb och internet": (
        "Google Chrome",
        "Brave",
        "Firefox",
        "Thunderbird",
        "Transmission",
        "FileZilla",
        "Termius",
    ),
    "Kontor och produktivitet": (
        "LibreOffice",
        "OnlyOffice",
        "Obsidian",
        "Bitwarden",
    ),
    "Kommunikation": (
        "Discord",
        "Element",
        "Slack",
        "Microsoft Teams",
        "Session",
        "Revolt",
        "Mumble",
        "TeamSpeak",
        "Caprine",
        "Fractal",
        "FluffyChat",
        "Zoom",
        "Skype",
        "Mattermost",
        "Zulip",
        "SimpleX Chat",
        "qTox",
        "Wire",
        "Guilded",
        "Jitsi Meet",
        "Telegram",
        "Signal",
    ),
    "Media och kreativt": (
        "Spotify",
        "VLC",
        "GIMP",
        "Krita",
        "Blender",
        "Flameshot",
        "Kdenlive",
        "Inkscape",
        "Audacity",
        "HandBrake",
        "Darktable",
        "Shotcut",
        "LosslessCut",
        "RawTherapee",
        "Natron",
        "Synfig Studio",
        "OpenShot",
        "Ardour",
        "Mixxx",
        "digiKam",
        "Scribus",
        "Olive",
        "Pitivi",
    ),
    "Spel": (
        "Steam",
        "Lutris",
        "Heroic Games Launcher",
        "ProtonUp-Qt",
        "MangoHud",
        "Goverlay",
        "Bottles",
        "Prism Launcher",
        "RetroArch",
        "Itch.io",
        "Piper",
        "GameMode",
        "Sunshine",
        "Moonlight",
        "OBS Studio",
        "Cartridges",
        "CoreCtrl",
        "Oversteer",
        "Greenlight",
    ),
    "Utveckling och teknik": (
        "Visual Studio Code",
        "KiCad",
        "Ansible",
        "Topgrade",
        "Chezmoi",
        "FreeCAD",
        "Postman",
        "Bruno",
        "Insomnia",
        "JetBrains Toolbox",
        "Neovim",
        "DBeaver",
        "GitKraken",
        "Lazygit",
        "Wireshark",
        "Godot Engine",
        "Meld",
        "Sublime Text",
        "Android Studio",
        "Sublime Merge",
    ),
    "Paket och systemverktyg": (
        "Bauh",
        "Flatpak",
        "Snapcraft",
        "AppImageLauncher",
        "Warehouse",
        "GNOME Software",
        "KDE Discover",
        "Synaptic",
        "Pacstall",
        "Homebrew",
        "Nix",
        "Distrobox",
        "Docker",
        "Podman",
        "Kitty",
        "Virt-Manager",
    ),
}
app_selections = {
    app_name: tk.BooleanVar(value=False)
    for category_apps in app_categories.values()
    for app_name in category_apps
}

tk.Label(
    app_content,
    text="Select apps to install or uninstall:",
    bg="#78B9F2",
    font=("arial", 12, "bold"),
).pack(pady=(20, 10))

style = ttk.Style(root)
style.configure("Apps.TFrame", background="#78B9F2")
tab_bar = tk.Frame(app_content, bg="#78B9F2")
tab_bar.pack(fill="x", padx=24, pady=(0, 8))


def rounded_rectangle(canvas, x1, y1, x2, y2, radius, **options):
    radius = min(radius, (x2 - x1) / 2, (y2 - y1) / 2)
    points = [
        x1 + radius, y1,
        x2 - radius, y1,
        x2 - radius / 2, y1,
        x2, y1 + radius / 2,
        x2, y1 + radius,
        x2, y2 - radius,
        x2, y2 - radius / 2,
        x2 - radius / 2, y2,
        x2 - radius, y2,
        x1 + radius, y2,
        x1 + radius / 2, y2,
        x1, y2 - radius / 2,
        x1, y2 - radius,
        x1, y1 + radius,
        x1, y1 + radius / 2,
        x1 + radius / 2, y1,
    ]
    return canvas.create_polygon(
        points,
        smooth=True,
        splinesteps=12,
        **options,
    )


class RoundedButton(tk.Canvas):
    def __init__(
        self,
        parent,
        text,
        command,
        bg,
        active_bg,
        font,
        padx=12,
        height=42,
        fg="#10243A",
    ):
        self.label = text
        self.command = command
        self.normal_bg = bg
        self.active_bg = active_bg
        self.foreground = fg
        self.button_font = tkfont.Font(root=parent, font=font)
        self.horizontal_padding = padx
        self.text_wraplength = 0
        self.enabled = True
        self.hovered = False
        super().__init__(
            parent,
            width=max(96, self.button_font.measure(text) + padx * 2),
            height=height,
            bg=parent.cget("bg"),
            highlightthickness=0,
            bd=0,
            takefocus=True,
        )
        self.bind("<Configure>", self._draw)
        self.bind("<Button-1>", self._invoke)
        self.bind("<space>", self._invoke)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self._draw()

    def _draw(self, _event=None):
        self.delete("all")
        width = self.winfo_width()
        height = self.winfo_height()
        if width <= 1 or height <= 1:
            return
        fill = self.active_bg if self.hovered else self.normal_bg
        foreground = self.foreground
        if not self.enabled:
            fill = "#B8CDE0"
            foreground = "#71879B"
        rounded_rectangle(
            self,
            1,
            1,
            width - 1,
            height - 1,
            10,
            fill=fill,
            outline="",
        )
        self.create_text(
            width / 2,
            height / 2,
            text=self.label,
            fill=foreground,
            font=self.button_font,
            justify="center",
            width=self.text_wraplength or max(
                1,
                width - self.horizontal_padding * 2,
            ),
        )

    def _invoke(self, _event=None):
        if self.enabled:
            self.command()

    def _on_enter(self, _event=None):
        self.hovered = True
        self._draw()

    def _on_leave(self, _event=None):
        self.hovered = False
        self._draw()

    def set_label(self, text):
        self.label = text
        self._draw()

    def set_colors(self, bg, active_bg):
        self.normal_bg = bg
        self.active_bg = active_bg
        self._draw()

    def set_wraplength(self, wraplength):
        self.text_wraplength = wraplength
        self._draw()

    def set_enabled(self, enabled):
        self.enabled = enabled
        self._draw()


class AppOption(tk.Canvas):
    def __init__(self, parent, app_name, selected):
        super().__init__(
            parent,
            width=190,
            height=40,
            bg="#78B9F2",
            highlightthickness=0,
            bd=0,
            takefocus=True,
        )
        self.app_name = app_name
        self.selected = selected
        self.bind("<Configure>", self._draw)
        self.bind("<Button-1>", self._toggle)
        self.bind("<space>", self._toggle)
        selected.trace_add("write", lambda *_args: self._draw())
        self._draw()

    def _draw(self, _event=None):
        self.delete("all")
        width = self.winfo_width()
        height = self.winfo_height()
        if width <= 1 or height <= 1:
            return
        rounded_rectangle(
            self,
            1,
            1,
            width - 1,
            height - 1,
            9,
            fill="#D9ECFF",
            outline="",
        )
        rounded_rectangle(
            self,
            10,
            height / 2 - 8,
            26,
            height / 2 + 8,
            4,
            fill="#B7DAFF",
            outline="#6485A4",
            width=1,
        )
        if self.selected.get():
            self.create_line(
                13,
                height / 2,
                16,
                height / 2 + 3,
                22,
                height / 2 - 4,
                fill="#183B5B",
                width=2,
                capstyle=tk.ROUND,
                joinstyle=tk.ROUND,
            )
        self.create_text(
            34,
            height / 2,
            text=self.app_name,
            fill="#10243A",
            font=("arial", 9),
            anchor="w",
            width=max(1, width - 44),
        )

    def _toggle(self, _event=None):
        self.selected.set(not self.selected.get())


category_actions = tk.Frame(app_content, bg="#78B9F2")
category_actions.pack(fill="x", padx=24, pady=(0, 4))
category_selection_button = RoundedButton(
    category_actions,
    "Select all in this category",
    lambda: toggle_category_selection(),
    bg="#5AA4E6",
    active_bg="#418FD3",
    font=("arial", 9),
    padx=10,
    height=36,
)
category_selection_button.pack(side="right")
all_apps_selection_button = RoundedButton(
    category_actions,
    "Select all apps",
    lambda: toggle_all_apps(),
    bg="#5AA4E6",
    active_bg="#418FD3",
    font=("arial", 9),
    padx=10,
    height=36,
)
all_apps_selection_button.pack(side="left")
category_content_area = tk.Frame(app_content, bg="#78B9F2")
category_content_area.pack(fill="both", expand=True, padx=24, pady=8)
tab_font = ("arial", 9, "bold")


def create_app_option(parent, app_name, selected, index):
    option = AppOption(parent, app_name, selected)
    option.grid(
        row=index // 3,
        column=index % 3,
        sticky="ew",
        padx=6,
        pady=5,
    )
    selected.trace_add(
        "write",
        lambda *_args: refresh_category_selection_button(),
    )
    selected.trace_add(
        "write",
        lambda *_args: refresh_all_apps_selection_button(),
    )


category_tabs = {}
category_pages = {}
for category_name, category_apps in app_categories.items():
    category_contents = ttk.Frame(
        category_content_area,
        style="Apps.TFrame",
        padding=16,
    )
    for column in range(3):
        category_contents.grid_columnconfigure(column, weight=1)
    for app_index, app_name in enumerate(category_apps):
        create_app_option(
            category_contents,
            app_name,
            app_selections[app_name],
            app_index,
        )
    category_pages[category_name] = category_contents
    category_tabs[category_name] = RoundedButton(
        tab_bar,
        category_name,
        lambda name=category_name: show_category(name),
        bg="#5AA4E6",
        active_bg="#418FD3",
        font=tab_font,
        padx=10,
        height=44,
    )


active_category = None


def refresh_category_selection_button():
    if active_category is None:
        return
    all_selected = all(
        app_selections[app_name].get()
        for app_name in app_categories[active_category]
    )
    category_selection_button.set_label(
        (
            "Deselect this category"
            if all_selected
            else "Select all in this category"
        )
    )


def refresh_all_apps_selection_button():
    all_selected = all(
        selected.get()
        for selected in app_selections.values()
    )
    all_apps_selection_button.set_label(
        "Deselect all apps" if all_selected else "Select all apps"
    )


def toggle_all_apps():
    select_apps = not all(
        selected.get()
        for selected in app_selections.values()
    )
    for selected in app_selections.values():
        selected.set(select_apps)


def toggle_category_selection():
    category_apps = app_categories[active_category]
    select_apps = not all(app_selections[app_name].get() for app_name in category_apps)
    for app_name in category_apps:
        app_selections[app_name].set(select_apps)


def show_category(category_name):
    global active_category
    if active_category is not None:
        category_pages[active_category].pack_forget()
    active_category = category_name
    category_pages[category_name].pack(fill="both", expand=True)
    for name, button in category_tabs.items():
        is_active = name == category_name
        button.set_colors(
            "#3D88CF" if is_active else "#5AA4E6",
            "#3478B9" if is_active else "#418FD3",
        )
    refresh_category_selection_button()


def arrange_category_tabs(_event=None):
    global tab_layout_job
    tab_layout_job = None
    available_width = tab_bar.winfo_width()
    if available_width <= 1:
        return

    spacing = 6
    column_count = min(
        len(category_tabs),
        max(1, min(4, available_width // 150)),
    )
    cell_width = (available_width - spacing * (column_count - 1)) // column_count
    for column in range(len(category_tabs)):
        tab_bar.grid_columnconfigure(column, weight=0, uniform="")

    for index, button in enumerate(category_tabs.values()):
        button.grid_forget()
        button.set_wraplength(max(80, cell_width - 24))
        button.grid(
            row=index // column_count,
            column=index % column_count,
            sticky="ew",
            padx=spacing // 2,
            pady=3,
        )
    for column in range(column_count):
        tab_bar.grid_columnconfigure(
            column,
            weight=1,
            uniform="category-tabs",
        )


tab_layout_job = None


def schedule_category_tabs(_event=None):
    global tab_layout_job
    if tab_layout_job is None:
        tab_layout_job = root.after_idle(arrange_category_tabs)


def rounded_rectangle(canvas, x1, y1, x2, y2, radius, **options):
    radius = min(radius, (x2 - x1) / 2, (y2 - y1) / 2)
    points = [
        x1 + radius, y1,
        x2 - radius, y1,
        x2 - radius / 2, y1,
        x2, y1 + radius / 2,
        x2, y1 + radius,
        x2, y2 - radius,
        x2, y2 - radius / 2,
        x2 - radius / 2, y2,
        x2 - radius, y2,
        x1 + radius, y2,
        x1 + radius / 2, y2,
        x1, y2 - radius / 2,
        x1, y2 - radius,
        x1, y1 + radius,
        x1, y1 + radius / 2,
        x1 + radius / 2, y1,
    ]
    return canvas.create_polygon(
        points,
        smooth=True,
        splinesteps=12,
        **options,
    )


class RoundedButton(tk.Canvas):
    def __init__(
        self,
        parent,
        text,
        command,
        bg,
        active_bg,
        font,
        padx=12,
        pady=7,
        height=42,
        fg="#10243A",
    ):
        self.label = text
        self.command = command
        self.normal_bg = bg
        self.active_bg = active_bg
        self.foreground = fg
        self.button_font = tkfont.Font(root=parent, font=font)
        self.horizontal_padding = padx
        self.vertical_padding = pady
        self.text_wraplength = 0
        self.enabled = True
        self.hovered = False
        super().__init__(
            parent,
            width=max(96, self.button_font.measure(text) + padx * 2),
            height=height,
            bg=parent.cget("bg"),
            highlightthickness=0,
            bd=0,
            takefocus=True,
        )
        self.bind("<Configure>", self._draw)
        self.bind("<Button-1>", self._invoke)
        self.bind("<space>", self._invoke)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self._draw()

    def _draw(self, _event=None):
        self.delete("all")
        width = self.winfo_width()
        height = self.winfo_height()
        if width <= 1 or height <= 1:
            return
        fill = self.normal_bg if not self.hovered else self.active_bg
        if not self.enabled:
            fill = "#B8CDE0"
        rounded_rectangle(
            self,
            1,
            1,
            width - 1,
            height - 1,
            10,
            fill=fill,
            outline="",
        )
        self.create_text(
            width / 2,
            height / 2,
            text=self.label,
            fill=self.foreground if self.enabled else "#71879B",
            font=self.button_font,
            justify="center",
            width=self.text_wraplength or max(1, width - self.horizontal_padding * 2),
        )

    def _invoke(self, _event=None):
        if self.enabled:
            self.command()

    def _on_enter(self, _event=None):
        self.hovered = True
        self._draw()

    def _on_leave(self, _event=None):
        self.hovered = False
        self._draw()

    def set_label(self, text):
        self.label = text
        self._draw()

    def set_colors(self, bg, active_bg):
        self.normal_bg = bg
        self.active_bg = active_bg
        self._draw()

    def set_wraplength(self, wraplength):
        self.text_wraplength = wraplength
        self._draw()

    def set_enabled(self, enabled):
        self.enabled = enabled
        self._draw()


class AppOption(tk.Canvas):
    def __init__(self, parent, app_name, selected):
        super().__init__(
            parent,
            width=190,
            height=40,
            bg="#78B9F2",
            highlightthickness=0,
            bd=0,
            takefocus=True,
        )
        self.app_name = app_name
        self.selected = selected
        self.bind("<Configure>", self._draw)
        self.bind("<Button-1>", self._toggle)
        self.bind("<space>", self._toggle)
        selected.trace_add("write", lambda *_args: self._draw())
        self._draw()

    def _draw(self, _event=None):
        self.delete("all")
        width = self.winfo_width()
        height = self.winfo_height()
        if width <= 1 or height <= 1:
            return
        rounded_rectangle(
            self,
            1,
            1,
            width - 1,
            height - 1,
            9,
            fill="#D9ECFF",
            outline="",
        )
        rounded_rectangle(
            self,
            10,
            height / 2 - 8,
            26,
            height / 2 + 8,
            4,
            fill="#B7DAFF",
            outline="#6485A4",
            width=1,
        )
        if self.selected.get():
            self.create_line(
                13,
                height / 2,
                16,
                height / 2 + 3,
                22,
                height / 2 - 4,
                fill="#183B5B",
                width=2,
                capstyle=tk.ROUND,
                joinstyle=tk.ROUND,
            )
        self.create_text(
            34,
            height / 2,
            text=self.app_name,
            fill="#10243A",
            font=("arial", 9),
            anchor="w",
        )

    def _toggle(self, _event=None):
        self.selected.set(not self.selected.get())


tab_bar.bind("<Configure>", schedule_category_tabs)
show_category(next(iter(app_categories)))

status_frame = tk.Canvas(
    app_content,
    height=152,
    bg="#78B9F2",
    highlightthickness=0,
)
status_frame.pack(fill="x", padx=24, pady=(6, 10))
status_background = rounded_rectangle(
    status_frame,
    0,
    0,
    1,
    1,
    14,
    fill="#3D88CF",
    outline="",
)
status_content = tk.Frame(status_frame, bg="#3D88CF")
status_window = status_frame.create_window(
    8,
    8,
    anchor="nw",
    window=status_content,
)


def resize_status_frame(event):
    status_frame.coords(status_background, 0, 0, event.width, event.height)
    status_frame.itemconfigure(status_window, width=max(1, event.width - 16))


status_frame.bind("<Configure>", resize_status_frame)
status_text = tk.Text(
    status_content,
    height=5,
    wrap="word",
    font=("arial", 10),
    fg="black",
    bg="#3D88CF",
    relief="flat",
    borderwidth=0,
    padx=8,
    pady=6,
    state="disabled",
)
status_text.pack(fill="x", expand=True)
install_progress = ttk.Progressbar(status_content, mode="indeterminate")

action_buttons = tk.Frame(app_content, bg="#78B9F2")
action_buttons.pack(pady=(0, 10))
install_button = RoundedButton(
    action_buttons,
    "Install selected apps",
    install_selected_apps,
    bg="#5AA4E6",
    active_bg="#418FD3",
    font=("arial", 9, "bold"),
    padx=12,
    height=44,
)
install_button.pack(side="left", padx=5)
uninstall_button = RoundedButton(
    action_buttons,
    "Uninstall selected apps",
    uninstall_selected_apps,
    bg="#5AA4E6",
    active_bg="#418FD3",
    font=("arial", 9, "bold"),
    padx=12,
    height=44,
)
uninstall_button.pack(side="left", padx=5)
pause_install_button = RoundedButton(
    action_buttons,
    "Pause installation",
    toggle_installation_pause,
    bg="#D9ECFF",
    active_bg="#B7DAFF",
    font=("arial", 9, "bold"),
    padx=12,
    height=44,
)
pause_install_button.pack(side="left", padx=5)
pause_install_button.set_enabled(False)
footer_frame = tk.Frame(app_content, bg="#78B9F2")
footer_frame.pack(fill="x", padx=24, pady=(0, 16))
remove_app_button = RoundedButton(
    footer_frame,
    "Uninstall Deez Appz",
    uninstall_deez_app,
    bg="#f3e2e2",
    active_bg="#ebcccc",
    font=("arial", 8),
    padx=8,
    height=34,
    fg="#5B2525",
)
remove_app_button.pack(side="left")

root.mainloop()
