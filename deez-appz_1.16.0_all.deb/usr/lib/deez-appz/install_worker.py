import json
import subprocess
import sys


APT_PACKAGES = {
    "MangoHud": "mangohud",
    "GameMode": "gamemode",
    "OBS Studio": "obs-studio",
    "CoreCtrl": "corectrl",
}
SNAP_PACKAGES = {
    "Discord": ("discord",),
    "Telegram": ("telegram-desktop",),
}
FLATPAK_APPS = {
    "Element": "im.riot.Riot",
    "Slack": "com.slack.Slack",
    "Microsoft Teams": "com.github.IsmaelMartinez.teams_for_linux",
    "Session": "network.loki.Session",
    "Mumble": "info.mumble.Mumble",
    "TeamSpeak": "com.teamspeak.TeamSpeak",
    "Caprine": "com.sindresorhus.Caprine",
    "Fractal": "org.gnome.Fractal",
    "FluffyChat": "im.fluffychat.Fluffychat",
    "Zoom": "us.zoom.Zoom",
    "Mattermost": "com.mattermost.Desktop",
    "Zulip": "org.zulip.Zulip",
    "SimpleX Chat": "chat.simplex.simplex",
    "qTox": "io.github.qtox.qTox",
    "Signal": "org.signal.Signal",
    "Steam": "com.valvesoftware.Steam",
    "Lutris": "net.lutris.Lutris",
    "Heroic Games Launcher": "com.heroicgameslauncher.hgl",
    "ProtonUp-Qt": "net.davidotek.pupgui2",
    "Goverlay": "io.github.benjamimgois.goverlay",
    "Bottles": "com.usebottles.bottles",
    "Prism Launcher": "org.prismlauncher.PrismLauncher",
    "RetroArch": "org.libretro.RetroArch",
    "Itch.io": "io.itch.itch",
    "Piper": "org.freedesktop.Piper",
    "Sunshine": "dev.lizardbyte.app.Sunshine",
    "Moonlight": "com.moonlight_stream.Moonlight",
    "Cartridges": "page.kramo.Cartridges",
    "Oversteer": "io.github.berarma.Oversteer",
    "Greenlight": "io.github.unknownskl.greenlight",
}
UNAVAILABLE_APPS = {
    "Revolt": "No verified Linux package is configured.",
    "Skype": "The Flathub package is marked end-of-life.",
    "Threema": "No verified Linux desktop package is configured.",
    "Wire": "No verified Linux desktop package is configured.",
    "Guilded": "No verified Linux desktop package is configured.",
    "Jitsi Meet": "No verified Linux desktop package is configured.",
}


def run_install(app_names):
    unknown_apps = set(app_names) - (
        set(APT_PACKAGES)
        | set(SNAP_PACKAGES)
        | set(FLATPAK_APPS)
        | set(UNAVAILABLE_APPS)
    )
    if unknown_apps:
        raise ValueError(f"Unsupported apps: {', '.join(sorted(unknown_apps))}")

    results = {
        name: UNAVAILABLE_APPS[name]
        for name in app_names
        if name in UNAVAILABLE_APPS
    }
    apt_apps = [name for name in app_names if name in APT_PACKAGES]
    if any(name in FLATPAK_APPS for name in app_names):
        apt_apps.append("Flatpak")
    if apt_apps:
        packages = [
            APT_PACKAGES[name] if name in APT_PACKAGES else "flatpak"
            for name in apt_apps
        ]
        if "Piper" in app_names:
            packages.append("ratbagd")
        try:
            subprocess.run(
                ["apt-get", "install", "-y", *packages],
                check=True,
                capture_output=True,
                text=True,
            )
            for name in apt_apps:
                if name != "Flatpak":
                    results[name] = "installed"
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            for name in apt_apps:
                if name != "Flatpak":
                    results[name] = f"installation failed ({detail.strip()})"
            if "Piper" in app_names:
                results["Piper"] = (
                    "installation failed: could not install ratbagd "
                    f"dependency ({detail.strip()})"
                )

    snap_apps = [name for name in app_names if name in SNAP_PACKAGES]
    for name in snap_apps:
        try:
            subprocess.run(
                ["snap", "install", *SNAP_PACKAGES[name]],
                check=True,
                capture_output=True,
                text=True,
            )
            results[name] = "installed"
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            results[name] = f"installation failed ({detail.strip()})"

    flatpak_apps = [name for name in app_names if name in FLATPAK_APPS]
    if flatpak_apps:
        try:
            subprocess.run(
                [
                    "flatpak",
                    "remote-add",
                    "--system",
                    "--if-not-exists",
                    "flathub",
                    "https://flathub.org/repo/flathub.flatpakrepo",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            for name in flatpak_apps:
                if name in results:
                    continue
                results[name] = (
                    f"installation failed: could not configure Flathub "
                    f"({detail.strip()})"
                )
        else:
            for name in flatpak_apps:
                if name in results:
                    continue
                try:
                    subprocess.run(
                        [
                            "flatpak",
                            "install",
                            "--system",
                            "--assumeyes",
                            "flathub",
                            FLATPAK_APPS[name],
                        ],
                        check=True,
                        capture_output=True,
                        text=True,
                    )
                    results[name] = (
                        "installed with ratbagd" if name == "Piper"
                        else "installed"
                    )
                    if name == "Sunshine":
                        try:
                            subprocess.run(
                                [
                                    "flatpak",
                                    "run",
                                    "--command=additional-install.sh",
                                    FLATPAK_APPS[name],
                                ],
                                check=True,
                                capture_output=True,
                                text=True,
                            )
                        except (OSError, subprocess.CalledProcessError) as error:
                            detail = getattr(error, "stderr", None) or str(error)
                            results[name] = (
                                "installed, but additional setup failed "
                                f"({detail.strip()})"
                            )
                except (OSError, subprocess.CalledProcessError) as error:
                    detail = getattr(error, "stderr", None) or str(error)
                    results[name] = f"installation failed ({detail.strip()})"

    print(json.dumps({name: results[name] for name in app_names}))


if __name__ == "__main__":
    run_install(sys.argv[1:])
