import importlib.util
import math
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request

if importlib.util.find_spec("tkinter") is None:
    if shutil.which("apt-get") is None:
        sys.exit("Tkinter is missing and this system does not use Ubuntu's package manager.")

    print("Tkinter is missing. Installing it...")
    subprocess.run(["pkexec", "apt-get", "update"], check=True)
    subprocess.run(
        ["pkexec", "apt-get", "install", "-y", "python3-tk"],
        check=True
    )

import tkinter as tk

root = tk.Tk()
root.title("Deez Appz")
root.geometry("800x600")
root.configure(bg="white")


def build_app_icon():
    icon = tk.PhotoImage(width=64, height=64)

    def set_pixel(x, y, color):
        if 0 <= x < 64 and 0 <= y < 64:
            icon.put(color, (x, y))

    def fill_circle(cx, cy, r, color):
        for y in range(max(0, cy - r), min(64, cy + r + 1)):
            for x in range(max(0, cx - r), min(64, cx + r + 1)):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                    set_pixel(x, y, color)

    def draw_ring(cx, cy, outer_r, inner_r, color):
        fill_circle(cx, cy, outer_r, color)
        fill_circle(cx, cy, inner_r, "#1c4f7d")

    def draw_tooth(cx, cy, radius, angle_deg, length=8, width=5, color="#2d9bd3"):
        angle = math.radians(angle_deg)
        for step in range(length):
            tx = int(round(cx + math.cos(angle) * (radius + step)))
            ty = int(round(cy + math.sin(angle) * (radius + step)))
            for dx in range(-width, width + 1):
                for dy in range(-width, width + 1):
                    if dx * dx + dy * dy <= width * width:
                        set_pixel(tx + dx, ty + dy, color)

    def fill_polygon(points, color):
        min_x = min(p[0] for p in points)
        max_x = max(p[0] for p in points)
        min_y = min(p[1] for p in points)
        max_y = max(p[1] for p in points)

        for y in range(max(0, min_y), min(64, max_y + 1)):
            for x in range(max(0, min_x), min(64, max_x + 1)):
                inside = False
                for index, point in enumerate(points):
                    x1, y1 = point
                    x2, y2 = points[(index + 1) % len(points)]
                    intersects = ((y1 > y) != (y2 > y)) and (
                        x < (x2 - x1) * (y - y1) / (y2 - y1) + x1
                    )
                    if intersects:
                        inside = not inside
                if inside:
                    set_pixel(x, y, color)

    for y in range(64):
        for x in range(64):
            dx = x - 32
            dy = y - 32
            if abs(dx) < 30 and abs(dy) < 30:
                r = min(1.0, 1.0 - (abs(dx) + abs(dy)) / 80)
                c1 = (22, 90, 148)
                c2 = (54, 191, 216)
                r1, g1, b1 = c1
                r2, g2, b2 = c2
                red = int(r1 + (r2 - r1) * (1 - (abs(dx) + abs(dy)) / 80))
                green = int(g1 + (g2 - g1) * (1 - (abs(dx) + abs(dy)) / 80))
                blue = int(b1 + (b2 - b1) * (1 - (abs(dx) + abs(dy)) / 80))
                icon.put(f'#{red:02x}{green:02x}{blue:02x}', (x, y))
            else:
                icon.put("#0b3a6d", (x, y))

    draw_ring(32, 32, 24, 12, "#4ec9d1")
    draw_ring(32, 32, 20, 14, "#1d5d8a")
    for angle in range(0, 360, 30):
        draw_tooth(32, 32, 24, angle, 8, 4, "#5fc7e8")

    fill_circle(32, 32, 8, "#2f9ad1")

    shaft_color = "#d7f4ff"
    fill_circle(32, 32, 4, shaft_color)

    arrow_points = [
        (32, 18),
        (22, 36),
        (28, 36),
        (28, 52),
        (36, 52),
        (36, 36),
        (42, 36),
    ]
    fill_polygon(arrow_points, "#a8f3ff")
    fill_polygon([(32, 18), (29, 12), (35, 12)], "#c9fbff")

    for x in range(8, 57):
        for y in range(58, 64):
            if (x - 32) ** 2 + (y - 61) ** 2 <= 7 ** 2:
                icon.put("#dffbff", (x, y))

    return icon


app_icon = build_app_icon()
root.iconphoto(True, app_icon)


def install_selected_apps():
    selected_apps = [
        app_name for app_name, selected in app_selections.items()
        if selected.get()
    ]
    if not selected_apps:
        label.config(text="Select at least one app to install.")
        return

    def install_google_chrome():
        with tempfile.TemporaryDirectory() as temp_dir:
            package_path = os.path.join(temp_dir, "google-chrome.deb")
            with urllib.request.urlopen(
                "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb",
                timeout=60,
            ) as response, open(package_path, "wb") as package:
                shutil.copyfileobj(response, package)
            subprocess.run(
                ["pkexec", "apt-get", "install", "-y", package_path],
                check=True,
            )

    installers = {
        "Visual Studio Code": lambda: subprocess.run(
            ["pkexec", "snap", "install", "code", "--classic"], check=True
        ),
        "Spotify": lambda: subprocess.run(
            ["pkexec", "snap", "install", "spotify"], check=True
        ),
        "Blender": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "blender"], check=True
        ),
        "KiCad": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "kicad"], check=True
        ),
        "Krita": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "krita"], check=True
        ),
        "Google Chrome": install_google_chrome,
        "Brave": lambda: subprocess.run(
            ["pkexec", "snap", "install", "brave"], check=True
        ),
        "Discord": lambda: subprocess.run(
            ["pkexec", "snap", "install", "discord"], check=True
        ),
    }
    results = []

    for app_name in selected_apps:
        label.config(text=f"Installing {app_name}...")
        root.update_idletasks()
        try:
            installers[app_name]()
            results.append(f"{app_name}: installed")
        except (OSError, subprocess.CalledProcessError) as error:
            results.append(f"{app_name}: installation failed ({error})")

    label.config(text="\n".join(results))

app_selections = {
    app_name: tk.BooleanVar(value=False)
    for app_name in (
        "Blender",
        "KiCad",
        "Visual Studio Code",
        "Spotify",
        "Krita",
        "Google Chrome",
        "Brave",
        "Discord",
    )
}

tk.Label(
    root,
    text="Select the apps you want to install:",
    bg="white",
    font=("arial", 12, "bold"),
).pack(pady=(32, 12))
apps_frame = tk.Frame(root, bg="white")
apps_frame.pack(fill="x", padx=120, pady=8)
apps_frame.grid_columnconfigure(0, weight=1)
apps_frame.grid_columnconfigure(1, weight=1)

for index, (app_name, selected) in enumerate(app_selections.items()):
    option_frame = tk.Frame(apps_frame, bg="white")
    option_frame.grid(row=index // 2, column=index % 2, sticky="w", padx=12, pady=10)
    indicator = tk.Canvas(
        option_frame,
        width=30,
        height=30,
        highlightthickness=0,
        takefocus=True,
        bg="white",
    )
    indicator.pack(side="left", padx=(0, 8))
    indicator.create_rectangle(3, 3, 27, 27, outline="#777777", width=2, fill="#d9d9d9")
    checkmark = indicator.create_line(
        8, 15, 13, 20, 22, 10, fill="#222222", width=3, state="hidden"
    )
    app_label = tk.Label(option_frame, text=app_name, font=("arial", 9), bg="white")
    app_label.pack(side="left")

    def toggle_selection(event=None, selection=selected, mark=checkmark, canvas=indicator):
        selection.set(not selection.get())
        canvas.itemconfigure(mark, state="normal" if selection.get() else "hidden")

    indicator.bind("<Button-1>", toggle_selection)
    indicator.bind("<space>", toggle_selection)
    app_label.bind("<Button-1>", toggle_selection)
    selected.trace_add(
        "write",
        lambda *_args, selection=selected, mark=checkmark, canvas=indicator: canvas.itemconfigure(
            mark, state="normal" if selection.get() else "hidden"
        ),
    )

label = tk.Label(
    root,
    text="",
    font=("arial", 10),
    fg="black",
    bg="white",
    wraplength=700,
)
label.pack(pady=24)

button = tk.Button(
    root,
    text="Install selected apps",
    command=install_selected_apps,
    bg="#d9d9d9",
    activebackground="#c8c8c8",
    relief="flat",
    padx=12,
    pady=6,
)
button.pack()

root.mainloop()
