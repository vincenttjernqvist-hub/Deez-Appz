import importlib.util
import json
import os
import platform
import pwd
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.error
import urllib.request

if importlib.util.find_spec("tkinter") is None:
    if shutil.which("apt-get") is None:
        sys.exit("Tkinter is missing and this system does not use Ubuntu's package manager.")

    print("Tkinter is missing. Installing it...")
    subprocess.run(["pkexec", "apt-get", "update"], check=True)
    subprocess.run(
        ["pkexec", "apt-get", "install", "-y", "python3-tk"],
        check=True
    )

import tkinter as tk
from tkinter import messagebox, ttk

root = tk.Tk()
root.title("Deez Appz")
root.geometry("1000x760")
root.minsize(640, 480)
root.configure(bg="#78B9F2")

app_canvas = tk.Canvas(root, bg="#78B9F2", highlightthickness=0)
app_scrollbar = ttk.Scrollbar(
    root,
    orient="vertical",
    command=app_canvas.yview,
)
app_canvas.configure(yscrollcommand=app_scrollbar.set)
app_scrollbar.pack(side="right", fill="y")
app_canvas.pack(side="left", fill="both", expand=True)
app_content = tk.Frame(app_canvas, bg="#78B9F2")
app_content_window = app_canvas.create_window(
    (0, 0),
    window=app_content,
    anchor="nw",
)


def update_scroll_region(_event=None):
    app_canvas.configure(scrollregion=app_canvas.bbox("all"))


def resize_app_content(event):
    app_canvas.itemconfigure(app_content_window, width=event.width)


def scroll_app(event):
    if event.num == 4:
        app_canvas.yview_scroll(-1, "units")
    elif event.num == 5:
        app_canvas.yview_scroll(1, "units")
    elif event.delta:
        app_canvas.yview_scroll(int(-event.delta / 120), "units")


app_content.bind("<Configure>", update_scroll_region)
app_canvas.bind("<Configure>", resize_app_content)
app_canvas.bind_all("<MouseWheel>", scroll_app)
app_canvas.bind_all("<Button-4>", scroll_app)
app_canvas.bind_all("<Button-5>", scroll_app)

app_icon_path = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "assets",
    "app-icon.png",
)
app_icon = tk.PhotoImage(file=app_icon_path)
root.iconphoto(True, app_icon)


MANUAL_INSTALLER_APPS = {
    "Google Chrome",
    "Bauh",
    "Topgrade",
    "AppImageLauncher",
    "Pacstall",
    "Homebrew",
}


def split_install_targets(selected_apps):
    """Identify apps that need custom setup around the privileged batch."""
    batch_apps = []
    manual_apps = []
    seen = set()

    for app_name in selected_apps:
        if app_name in seen:
            continue
        seen.add(app_name)
        if app_name in MANUAL_INSTALLER_APPS:
            manual_apps.append(app_name)
        else:
            batch_apps.append(app_name)

    return batch_apps, manual_apps


def set_status(message):
    status_text.configure(state="normal")
    status_text.delete("1.0", "end")
    status_text.insert("end", message)
    status_text.configure(height=max(5, message.count("\n") + 1))
    status_text.see("end")
    status_text.configure(state="disabled")


install_progress_queue = queue.Queue()
install_worker_latest_progress = None
install_worker_progress_value = 0.0


def show_worker_progress(progress):
    global install_worker_latest_progress, install_worker_progress_value

    if progress.get("event") == "started":
        install_worker_progress_value = 0.0
    if "completed" not in progress and install_worker_latest_progress:
        progress = {**install_worker_latest_progress, **progress}
    install_worker_latest_progress = progress

    completed = progress.get("completed", 0)
    total = progress.get("total", 0)
    progress_value = completed
    if progress.get("batch_count") and progress.get("percent") is not None:
        batch_fraction = progress["percent"] / 100
        if progress.get("stage") == "download":
            batch_fraction *= 0.5
        elif progress.get("stage") == "install":
            batch_fraction = 0.5 + batch_fraction * 0.5
        progress_value += progress["batch_count"] * batch_fraction
    install_worker_progress_value = min(
        total,
        max(install_worker_progress_value, progress_value),
    )
    percentage = (
        int(install_worker_progress_value * 100 / total)
        if total
        else 0
    )
    install_progress.stop()
    install_progress.configure(
        mode="determinate",
        maximum=max(total, 1),
        value=install_worker_progress_value,
    )

    phase = progress.get("message")
    if not phase and progress.get("app"):
        phase = f"Completed {progress['app']}"
    if not phase:
        phase = "Installation started"
    set_status(
        f"Installing apps: {percentage}% ({completed}/{total})\n"
        f"{phase}"
    )


def poll_install_progress():
    try:
        while True:
            event, message = install_progress_queue.get_nowait()
            if event == "status":
                install_progress.stop()
                install_progress.configure(mode="indeterminate")
                install_progress.start(12)
                set_status(message)
                continue
            if event == "download_start":
                app_name, total_bytes = message
                install_progress.stop()
                if total_bytes:
                    install_progress.configure(
                        mode="determinate",
                        maximum=100,
                        value=0,
                    )
                    set_status(f"Downloading {app_name}: 0%")
                else:
                    install_progress.configure(mode="indeterminate")
                    install_progress.start(12)
                    set_status(f"Downloading {app_name}...")
                continue
            if event == "worker_progress":
                show_worker_progress(message)
                continue
            if event == "download_progress":
                app_name, received_bytes, total_bytes = message
                percentage = min(100, int(received_bytes * 100 / total_bytes))
                install_progress.configure(value=percentage)
                set_status(f"Downloading {app_name}: {percentage}%")
                if percentage == 100:
                    root.after(250, poll_install_progress)
                    return
                continue

            install_progress.stop()
            install_progress.pack_forget()
            install_button.configure(state="normal")
            uninstall_button.configure(state="normal")
            set_status(message)
            return
    except queue.Empty:
        root.after(100, poll_install_progress)


def run_installation(selected_apps):
    try:
        result_message = perform_install_selected_apps(selected_apps)
    except Exception as error:
        result_message = f"Installation failed unexpectedly ({error})"
    install_progress_queue.put(("done", result_message))


def uninstall_deez_app():
    try:
        package_status = subprocess.run(
            [
                "dpkg-query",
                "-W",
                "-f=${db:Status-Abbrev}",
                "deez-appz",
            ],
            check=False,
            capture_output=True,
            text=True,
        )
    except OSError as error:
        messagebox.showerror(
            "Unable to check installation",
            f"Could not check whether Deez Appz is installed: {error}",
            parent=root,
        )
        return

    if package_status.returncode != 0 or not package_status.stdout.startswith("ii "):
        messagebox.showinfo(
            "Deez Appz is not installed as a package",
            "This copy of Deez Appz was not installed as a Debian package, "
            "so it cannot remove itself safely. No files were changed.",
            parent=root,
        )
        return

    if not messagebox.askyesno(
        "Uninstall Deez Appz",
        "Remove Deez Appz from this computer? The app will close after "
        "uninstallation. Your project files and downloaded app packages "
        "will not be removed.",
        parent=root,
    ):
        return

    set_status("Uninstalling Deez Appz...")
    root.update_idletasks()
    try:
        subprocess.run(
            ["pkexec", "apt-get", "remove", "-y", "deez-appz"],
            check=True,
        )
    except (OSError, subprocess.CalledProcessError) as error:
        set_status(f"Could not uninstall Deez Appz ({error})")
        messagebox.showerror(
            "Uninstallation failed",
            f"Deez Appz could not be uninstalled: {error}",
            parent=root,
        )
        return

    root.destroy()


def install_selected_apps():
    global install_worker_latest_progress
    global install_worker_progress_value
    selected_apps = [
        app_name for app_name, selected in app_selections.items()
        if selected.get()
    ]
    if not selected_apps:
        set_status("Select at least one app to install.")
        return

    install_button.configure(state="disabled")
    uninstall_button.configure(state="disabled")
    install_worker_latest_progress = None
    install_worker_progress_value = 0.0
    install_progress.pack(fill="x", pady=(6, 0))
    install_progress.start(12)
    set_status("Preparing installation...")
    threading.Thread(
        target=run_installation,
        args=(selected_apps,),
        daemon=True,
    ).start()
    root.after(100, poll_install_progress)


def perform_install_selected_apps(selected_apps):
    _, selected_manual_apps = split_install_targets(selected_apps)
    results = {}

    with tempfile.TemporaryDirectory(prefix="deez-appz-install-") as temp_dir:
        manual_paths = {}
        download_urls = {
            "Google Chrome": (
                "google_chrome_deb",
                "https://dl.google.com/linux/direct/"
                "google-chrome-stable_current_amd64.deb",
            ),
            "Pacstall": (
                "pacstall_installer",
                "https://pacstall.dev/q/install",
            ),
            "Homebrew": (
                "homebrew_installer",
                "https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh",
            ),
        }
        appimage_arch = {
            "x86_64": "x86_64",
            "aarch64": "aarch64",
            "armv7l": "armhf",
        }.get(platform.machine())
        if "AppImageLauncher" in selected_manual_apps:
            if appimage_arch is None:
                results["AppImageLauncher"] = (
                    "installation failed (unsupported CPU architecture)"
                )
            else:
                download_urls["AppImageLauncher"] = (
                    "appimagelauncher_lite",
                    "https://github.com/TheAssassin/AppImageLauncher/releases/"
                    "download/v3.0.0-beta-3/"
                    f"appimagelauncher-lite-3.0.0-beta-2-gha287-{appimage_arch}.AppImage",
                )
        for app_name in selected_manual_apps:
            if app_name not in download_urls:
                continue
            key, url = download_urls[app_name]
            file_name = (
                "google_chrome.deb"
                if app_name == "Google Chrome"
                else key
            )
            file_path = os.path.join(temp_dir, file_name)
            try:
                with urllib.request.urlopen(url, timeout=60) as response:
                    try:
                        total_bytes = int(response.headers.get("Content-Length", "0"))
                    except ValueError:
                        total_bytes = 0
                    install_progress_queue.put((
                        "download_start",
                        (app_name, total_bytes),
                    ))
                    with open(file_path, "wb") as downloaded_file:
                        received_bytes = 0
                        last_percentage = -1
                        while chunk := response.read(64 * 1024):
                            downloaded_file.write(chunk)
                            received_bytes += len(chunk)
                            if total_bytes:
                                percentage = min(
                                    100,
                                    int(received_bytes * 100 / total_bytes),
                                )
                                if percentage != last_percentage:
                                    install_progress_queue.put((
                                        "download_progress",
                                        (app_name, received_bytes, total_bytes),
                                    ))
                                    last_percentage = percentage
                    if total_bytes:
                        install_progress_queue.put((
                            "download_progress",
                            (app_name, total_bytes, total_bytes),
                        ))
                manual_paths[key] = file_path
            except (OSError, urllib.error.URLError) as error:
                results[app_name] = f"installation failed ({error})"

        worker_apps = [
            app_name for app_name in selected_apps
            if app_name not in results and app_name != "AppImageLauncher"
        ]
        if worker_apps or "AppImageLauncher" in selected_manual_apps:
            install_progress_queue.put(("status", "Starting app installation..."))
            worker_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "install_worker.py",
            )
            request_path = os.path.join(temp_dir, "install-request.json")
            user = pwd.getpwuid(os.getuid())
            request = {
                "apps": worker_apps,
                "manual_install_data": {
                    "paths": manual_paths,
                    "uid": user.pw_uid,
                    "gid": user.pw_gid,
                    "progress_total": len(worker_apps) + int(
                        "appimagelauncher_lite" in manual_paths
                    ),
                    "remove_deprecated_appimagelauncher_ppa": (
                        "AppImageLauncher" in selected_manual_apps
                    ),
                },
            }
            with open(request_path, "w", encoding="utf-8") as request_file:
                json.dump(request, request_file)

            worker_progress_completed = 0
            worker_progress_total = request["manual_install_data"]["progress_total"]
            external_progress_completed = set()

            def report_external_completion(app_name):
                if app_name in external_progress_completed:
                    return
                external_progress_completed.add(app_name)
                install_progress_queue.put((
                    "worker_progress",
                    {
                        "event": "app_complete",
                        "app": app_name,
                        "completed": worker_progress_completed + len(external_progress_completed),
                        "total": worker_progress_total,
                    },
                ))

            try:
                worker_command = [
                    "pkexec",
                    sys.executable,
                    worker_path,
                    "--request-file",
                    request_path,
                ]
                worker_process = subprocess.Popen(
                    worker_command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                )
                worker_errors = []
                for line in worker_process.stderr:
                    if line.startswith("DEEZ_PROGRESS "):
                        try:
                            progress_event = json.loads(line[len("DEEZ_PROGRESS "):])
                        except json.JSONDecodeError:
                            worker_errors.append(line)
                            continue
                        worker_progress_completed = progress_event.get(
                            "completed",
                            worker_progress_completed,
                        )
                        worker_progress_total = progress_event.get(
                            "total",
                            worker_progress_total,
                        )
                        install_progress_queue.put(("worker_progress", progress_event))
                    else:
                        worker_errors.append(line)
                worker_stdout = worker_process.stdout.read()
                worker_returncode = worker_process.wait()
                if worker_returncode:
                    raise subprocess.CalledProcessError(
                        worker_returncode,
                        worker_command,
                        output=worker_stdout,
                        stderr="".join(worker_errors),
                    )
                worker_results = json.loads(worker_stdout)
                maintenance_results = worker_results.pop("__maintenance__", {})
                results.update(worker_results)
                ppa_cleanup = maintenance_results.get("appimagelauncher_ppa")
                if ppa_cleanup and ppa_cleanup != "removed":
                    results["AppImageLauncher"] = (
                        f"warning: {ppa_cleanup}"
                    )
            except (
                OSError,
                subprocess.CalledProcessError,
                json.JSONDecodeError,
                KeyError,
            ) as error:
                results.update({
                    app_name: f"installation failed ({error})"
                    for app_name in worker_apps
                })
                if "AppImageLauncher" in selected_manual_apps:
                    results["AppImageLauncher"] = (
                        f"warning: could not clean up its old apt source ({error})"
                    )

        user_setup_commands = {
            "Bauh": ["pipx", "install", "--system-site-packages", "bauh"],
            "Topgrade": ["cargo", "install", "--locked", "topgrade"],
        }
        for app_name, command in user_setup_commands.items():
            if results.get(app_name) != "ready for user setup":
                continue
            try:
                install_progress_queue.put((
                    "worker_progress",
                    {"event": "phase", "message": f"Setting up {app_name}..."},
                ))
                subprocess.run(command, check=True)
                results[app_name] = "installed"
            except (OSError, subprocess.CalledProcessError) as error:
                results[app_name] = f"installation failed ({error})"
            if "report_external_completion" in locals():
                report_external_completion(app_name)

        if results.get("Homebrew") == "ready for user setup":
            try:
                install_progress_queue.put((
                    "worker_progress",
                    {"event": "phase", "message": "Setting up Homebrew..."},
                ))
                subprocess.run(
                    ["/bin/bash", manual_paths["homebrew_installer"]],
                    check=True,
                    env={**os.environ, "NONINTERACTIVE": "1"},
                )
                results["Homebrew"] = "installed"
            except (KeyError, OSError, subprocess.CalledProcessError) as error:
                results["Homebrew"] = f"installation failed ({error})"
            if "report_external_completion" in locals():
                report_external_completion("Homebrew")

        if (
            "AppImageLauncher" in selected_manual_apps
            and "appimagelauncher_lite" in manual_paths
        ):
            appimage_path = manual_paths["appimagelauncher_lite"]
            try:
                install_progress_queue.put((
                    "worker_progress",
                    {"event": "phase", "message": "Setting up AppImageLauncher..."},
                ))
                os.chmod(appimage_path, 0o755)
                subprocess.run(
                    [appimage_path, "install"],
                    check=True,
                )
                cleanup_warning = results.get("AppImageLauncher")
                results["AppImageLauncher"] = (
                    "installed for current user"
                    if not cleanup_warning
                    else f"installed for current user; {cleanup_warning}"
                )
            except (OSError, subprocess.CalledProcessError) as error:
                results["AppImageLauncher"] = (
                    f"installation failed ({error})"
                )
            if "report_external_completion" in locals():
                report_external_completion("AppImageLauncher")

        if "report_external_completion" in locals():
            for app_name in ("Bauh", "Topgrade", "Homebrew"):
                if app_name in worker_apps:
                    report_external_completion(app_name)

    return "\n".join(
        f"{app_name}: {results.get(app_name, 'installation failed (no result returned)')}"
        for app_name in selected_apps
    )


def uninstall_selected_apps():
    selected_apps = [
        app_name for app_name, selected in app_selections.items()
        if selected.get()
    ]
    if not selected_apps:
        set_status("Select at least one app to uninstall.")
        return
    if not messagebox.askyesno(
        "Confirm uninstall",
        "Uninstall the selected apps and remove their system configuration, "
        "user settings, and cache? Game libraries, saves, documents, and "
        "other personal content will be kept.",
        parent=root,
    ):
        return
    results = {}
    set_status("Uninstalling selected apps and cleaning their settings...")
    root.update_idletasks()
    worker_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "install_worker.py",
    )
    try:
        with tempfile.TemporaryDirectory(
            prefix="deez-appz-uninstall-"
        ) as temp_dir:
            request_path = os.path.join(temp_dir, "uninstall-request.json")
            with open(request_path, "w", encoding="utf-8") as request_file:
                json.dump({
                    "apps": selected_apps,
                    "uid": os.getuid(),
                }, request_file)
            worker_result = subprocess.run(
                [
                    "pkexec",
                    sys.executable,
                    worker_path,
                    "--uninstall-request-file",
                    request_path,
                ],
                check=True,
                capture_output=True,
                text=True,
            )
        results.update(json.loads(worker_result.stdout))
    except (
        OSError,
        subprocess.CalledProcessError,
        json.JSONDecodeError,
    ) as error:
        results.update({
            app_name: f"uninstallation failed ({error})"
            for app_name in selected_apps
        })

    set_status("\n".join(
        f"{app_name}: {results.get(app_name, 'uninstallation failed (no result returned)')}"
        for app_name in selected_apps
    ))


app_categories = {
    "Webb och internet": (
        "Google Chrome",
        "Brave",
        "Firefox",
        "Thunderbird",
        "Transmission",
    ),
    "Kontor och produktivitet": (
        "LibreOffice",
        "OnlyOffice",
        "Obsidian",
        "Bitwarden",
    ),
    "Kommunikation": (
        "Discord",
        "Element",
        "Slack",
        "Microsoft Teams",
        "Session",
        "Revolt",
        "Mumble",
        "TeamSpeak",
        "Caprine",
        "Fractal",
        "FluffyChat",
        "Zoom",
        "Skype",
        "Mattermost",
        "Zulip",
        "SimpleX Chat",
        "qTox",
        "Wire",
        "Guilded",
        "Jitsi Meet",
        "Telegram",
        "Signal",
    ),
    "Media och kreativt": (
        "Spotify",
        "VLC",
        "GIMP",
        "Krita",
        "Blender",
        "Flameshot",
    ),
    "Spel": (
        "Steam",
        "Lutris",
        "Heroic Games Launcher",
        "ProtonUp-Qt",
        "MangoHud",
        "Goverlay",
        "Bottles",
        "Prism Launcher",
        "RetroArch",
        "Itch.io",
        "Piper",
        "GameMode",
        "Sunshine",
        "Moonlight",
        "OBS Studio",
        "Cartridges",
        "CoreCtrl",
        "Oversteer",
        "Greenlight",
    ),
    "Utveckling och teknik": (
        "Visual Studio Code",
        "KiCad",
        "Ansible",
        "Topgrade",
        "Chezmoi",
    ),
    "Paket och systemverktyg": (
        "Bauh",
        "Flatpak",
        "Snapcraft",
        "AppImageLauncher",
        "Warehouse",
        "GNOME Software",
        "KDE Discover",
        "Synaptic",
        "Pacstall",
        "Homebrew",
        "Nix",
        "Distrobox",
    ),
}
app_selections = {
    app_name: tk.BooleanVar(value=False)
    for category_apps in app_categories.values()
    for app_name in category_apps
}

tk.Label(
    app_content,
    text="Select apps to install or uninstall:",
    bg="#78B9F2",
    font=("arial", 12, "bold"),
).pack(pady=(20, 10))

style = ttk.Style(root)
style.configure("Apps.TFrame", background="#78B9F2")
tab_bar = tk.Frame(app_content, bg="#78B9F2")
tab_bar.pack(fill="x", padx=24, pady=(0, 8))
category_actions = tk.Frame(app_content, bg="#78B9F2")
category_actions.pack(fill="x", padx=24, pady=(0, 4))
category_selection_button = tk.Button(
    category_actions,
    text="Select all in this category",
    command=lambda: toggle_category_selection(),
    bg="#5AA4E6",
    activebackground="#418FD3",
    relief="flat",
    padx=10,
    pady=5,
)
category_selection_button.pack(side="right")
category_content_area = tk.Frame(app_content, bg="#78B9F2")
category_content_area.pack(fill="both", expand=True, padx=24, pady=8)
tab_font = ("arial", 9, "bold")


def create_app_option(parent, app_name, selected, index):
    option_frame = tk.Frame(parent, bg="#D9ECFF", padx=8, pady=6)
    option_frame.grid(
        row=index // 3,
        column=index % 3,
        sticky="ew",
        padx=6,
        pady=5,
    )
    indicator = tk.Canvas(
        option_frame,
        width=30,
        height=30,
        highlightthickness=0,
        takefocus=True,
        bg="#D9ECFF",
    )
    indicator.pack(side="left", padx=(0, 8))
    indicator.create_rectangle(
        3,
        3,
        27,
        27,
        outline="#777777",
        width=2,
        fill="#B7DAFF",
    )
    checkmark = indicator.create_line(
        8,
        15,
        13,
        20,
        22,
        10,
        fill="#222222",
        width=3,
        state="hidden",
    )
    app_label = tk.Label(
        option_frame,
        text=app_name,
        font=("arial", 9),
        bg="#D9ECFF",
        anchor="w",
    )
    app_label.pack(side="left")

    def toggle_selection(event=None):
        selected.set(not selected.get())

    indicator.bind("<Button-1>", toggle_selection)
    indicator.bind("<space>", toggle_selection)
    app_label.bind("<Button-1>", toggle_selection)
    selected.trace_add(
        "write",
        lambda *_args: indicator.itemconfigure(
            checkmark,
            state="normal" if selected.get() else "hidden",
        ),
    )
    selected.trace_add(
        "write",
        lambda *_args: refresh_category_selection_button(),
    )


category_tabs = {}
category_pages = {}
for category_name, category_apps in app_categories.items():
    category_contents = ttk.Frame(
        category_content_area,
        style="Apps.TFrame",
        padding=16,
    )
    for column in range(3):
        category_contents.grid_columnconfigure(column, weight=1)
    for app_index, app_name in enumerate(category_apps):
        create_app_option(
            category_contents,
            app_name,
            app_selections[app_name],
            app_index,
        )
    category_pages[category_name] = category_contents
    category_tabs[category_name] = tk.Button(
        tab_bar,
        text=category_name,
        font=tab_font,
        padx=10,
        pady=8,
        justify="center",
        relief="flat",
        borderwidth=0,
        bg="#5AA4E6",
        activebackground="#418FD3",
        command=lambda name=category_name: show_category(name),
    )


active_category = None


def refresh_category_selection_button():
    if active_category is None:
        return
    all_selected = all(
        app_selections[app_name].get()
        for app_name in app_categories[active_category]
    )
    category_selection_button.configure(
        text=(
            "Deselect this category"
            if all_selected
            else "Select all in this category"
        )
    )


def toggle_category_selection():
    category_apps = app_categories[active_category]
    select_apps = not all(app_selections[app_name].get() for app_name in category_apps)
    for app_name in category_apps:
        app_selections[app_name].set(select_apps)


def show_category(category_name):
    global active_category
    if active_category is not None:
        category_pages[active_category].pack_forget()
    active_category = category_name
    category_pages[category_name].pack(fill="both", expand=True)
    for name, button in category_tabs.items():
        is_active = name == category_name
        button.configure(
            bg="#3D88CF" if is_active else "#5AA4E6",
            relief="sunken" if is_active else "flat",
        )
    refresh_category_selection_button()


def arrange_category_tabs(_event=None):
    global tab_layout_job
    tab_layout_job = None
    available_width = tab_bar.winfo_width()
    if available_width <= 1:
        return

    spacing = 6
    column_count = min(
        len(category_tabs),
        max(1, min(4, available_width // 150)),
    )
    cell_width = (available_width - spacing * (column_count - 1)) // column_count
    for column in range(len(category_tabs)):
        tab_bar.grid_columnconfigure(column, weight=0, uniform="")

    for index, button in enumerate(category_tabs.values()):
        button.grid_forget()
        button.configure(wraplength=max(80, cell_width - 24))
        button.grid(
            row=index // column_count,
            column=index % column_count,
            sticky="ew",
            padx=spacing // 2,
            pady=3,
        )
    for column in range(column_count):
        tab_bar.grid_columnconfigure(
            column,
            weight=1,
            uniform="category-tabs",
        )


tab_layout_job = None


def schedule_category_tabs(_event=None):
    global tab_layout_job
    if tab_layout_job is None:
        tab_layout_job = root.after_idle(arrange_category_tabs)


tab_bar.bind("<Configure>", schedule_category_tabs)
show_category(next(iter(app_categories)))

status_frame = tk.Frame(app_content, bg="#3D88CF")
status_frame.pack(fill="x", padx=24, pady=(6, 10))
status_text = tk.Text(
    status_frame,
    height=5,
    wrap="word",
    font=("arial", 10),
    fg="black",
    bg="#3D88CF",
    relief="solid",
    borderwidth=1,
    state="disabled",
)
status_text.pack(fill="x", expand=True)
install_progress = ttk.Progressbar(status_frame, mode="indeterminate")

action_buttons = tk.Frame(app_content, bg="#78B9F2")
action_buttons.pack(pady=(0, 10))
install_button = tk.Button(
    action_buttons,
    text="Install selected apps",
    command=install_selected_apps,
    bg="#5AA4E6",
    activebackground="#418FD3",
    relief="flat",
    padx=12,
    pady=6,
)
install_button.pack(side="left", padx=5)
uninstall_button = tk.Button(
    action_buttons,
    text="Uninstall selected apps",
    command=uninstall_selected_apps,
    bg="#5AA4E6",
    activebackground="#418FD3",
    relief="flat",
    padx=12,
    pady=6,
)
uninstall_button.pack(side="left", padx=5)
footer_frame = tk.Frame(app_content, bg="#78B9F2")
footer_frame.pack(fill="x", padx=24, pady=(0, 16))
remove_app_button = tk.Button(
    footer_frame,
    text="Uninstall Deez Appz",
    command=uninstall_deez_app,
    bg="#f3e2e2",
    activebackground="#ebcccc",
    relief="flat",
    font=("arial", 8),
    padx=8,
    pady=3,
)
remove_app_button.pack(side="left")

root.mainloop()
