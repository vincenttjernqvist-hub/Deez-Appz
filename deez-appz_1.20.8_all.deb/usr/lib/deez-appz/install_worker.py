import json
import os
import pwd
import shutil
import subprocess
import sys
from pathlib import Path


APT_PACKAGES = {
    "Google Chrome": "google-chrome-stable",
    "Blender": "blender",
    "KiCad": "kicad",
    "Krita": "krita",
    "Flatpak": "flatpak",
    "GNOME Software": "gnome-software",
    "KDE Discover": "plasma-discover",
    "Synaptic": "synaptic",
    "Nix": "nix-bin",
    "Distrobox": "distrobox",
    "Ansible": "ansible",
    "VLC": "vlc",
    "LibreOffice": "libreoffice",
    "MangoHud": "mangohud",
    "GameMode": "gamemode",
    "OBS Studio": "obs-studio",
    "GIMP": "gimp",
    "Flameshot": "flameshot",
    "Transmission": "transmission-gtk",
    "CoreCtrl": "corectrl",
    "AppImageLauncher": "appimagelauncher",
}
SNAP_PACKAGES = {
    "Visual Studio Code": ("code", "--classic"),
    "Spotify": ("spotify",),
    "Brave": ("brave",),
    "Discord": ("discord",),
    "Snapcraft": ("snapcraft", "--classic"),
    "Chezmoi": ("chezmoi", "--classic"),
    "Firefox": ("firefox",),
    "Telegram": ("telegram-desktop",),
    "Thunderbird": ("thunderbird",),
}
FLATPAK_APPS = {
    "Warehouse": "io.github.flattool.Warehouse",
    "OnlyOffice": "org.onlyoffice.desktopeditors",
    "Bitwarden": "com.bitwarden.desktop",
    "Obsidian": "md.obsidian.Obsidian",
    "Element": "im.riot.Riot",
    "Slack": "com.slack.Slack",
    "Microsoft Teams": "com.github.IsmaelMartinez.teams_for_linux",
    "Session": "network.loki.Session",
    "Mumble": "info.mumble.Mumble",
    "TeamSpeak": "com.teamspeak.TeamSpeak",
    "Caprine": "com.sindresorhus.Caprine",
    "Fractal": "org.gnome.Fractal",
    "FluffyChat": "im.fluffychat.Fluffychat",
    "Zoom": "us.zoom.Zoom",
    "Mattermost": "com.mattermost.Desktop",
    "Zulip": "org.zulip.Zulip",
    "SimpleX Chat": "chat.simplex.simplex",
    "qTox": "io.github.qtox.qTox",
    "Signal": "org.signal.Signal",
    "Steam": "com.valvesoftware.Steam",
    "Lutris": "net.lutris.Lutris",
    "Heroic Games Launcher": "com.heroicgameslauncher.hgl",
    "ProtonUp-Qt": "net.davidotek.pupgui2",
    "Goverlay": "io.github.benjamimgois.goverlay",
    "Bottles": "com.usebottles.bottles",
    "Prism Launcher": "org.prismlauncher.PrismLauncher",
    "RetroArch": "org.libretro.RetroArch",
    "Itch.io": "io.itch.itch",
    "Piper": "org.freedesktop.Piper",
    "Sunshine": "dev.lizardbyte.app.Sunshine",
    "Moonlight": "com.moonlight_stream.Moonlight",
    "Cartridges": "page.kramo.Cartridges",
    "Oversteer": "io.github.berarma.Oversteer",
    "Greenlight": "io.github.unknownskl.greenlight",
    "Revolt": "chat.revolt.RevoltDesktop",
    "Jitsi Meet": "org.jitsi.jitsi-meet",
    "Heroic Games Launcher": "com.heroicgameslauncher.hgl",
}
UNAVAILABLE_APPS = {
    "Skype": "Skype was retired by Microsoft in May 2025.",
    "Wire": "No supported Linux desktop package is currently configured.",
    "Guilded": "Guilded does not currently offer a Linux desktop package.",
}
MANUAL_INSTALL_APPS = {
    "Google Chrome",
    "Bauh",
    "Topgrade",
    "Pacstall",
    "Homebrew",
}
APP_CONFIG_PATHS = {
    "Google Chrome": (".config/google-chrome", ".cache/google-chrome"),
    "Blender": (".config/blender", ".cache/blender"),
    "KiCad": (".config/kicad", ".cache/kicad"),
    "Krita": (".config/kritarc", ".cache/krita"),
    "LibreOffice": (".config/libreoffice", ".cache/libreoffice"),
    "VLC": (".config/vlc", ".cache/vlc"),
    "GIMP": (".config/GIMP", ".cache/GIMP"),
    "Flameshot": (".config/flameshot", ".cache/flameshot"),
    "Transmission": (".config/transmission", ".cache/transmission"),
    "MangoHud": (".config/MangoHud", ".cache/MangoHud"),
    "GameMode": (".config/gamemode", ".cache/gamemode"),
    "CoreCtrl": (".config/corectrl", ".cache/corectrl"),
    "OBS Studio": (".config/obs-studio", ".cache/obs-studio"),
    "Steam": (
        ".config/steam",
        ".cache/steam",
        ".local/share/Steam/config",
        ".steam/steam/config",
    ),
    "Lutris": (".config/lutris", ".cache/lutris"),
    "Heroic Games Launcher": (".config/heroic", ".cache/heroic"),
    "Bauh": (".config/bauh", ".cache/bauh"),
    "Topgrade": (".config/topgrade.toml", ".cache/topgrade"),
}
SNAP_NAMES = {
    "Visual Studio Code": "code",
    "Spotify": "spotify",
    "Brave": "brave",
    "Discord": "discord",
    "Snapcraft": "snapcraft",
    "Chezmoi": "chezmoi",
    "Firefox": "firefox",
    "Telegram": "telegram-desktop",
    "Thunderbird": "thunderbird",
}
USER_UNINSTALL_COMMANDS = {
    "Bauh": ("pipx", "uninstall", "bauh"),
    "Topgrade": ("cargo", "uninstall", "topgrade"),
}


def remove_user_settings(app_name, home):
    paths = list(APP_CONFIG_PATHS.get(app_name, ()))
    flatpak_id = FLATPAK_APPS.get(app_name)
    if flatpak_id:
        paths.extend((
            f".var/app/{flatpak_id}/config",
            f".var/app/{flatpak_id}/cache",
        ))
    snap_name = SNAP_NAMES.get(app_name)
    if snap_name:
        paths.extend((
            f"snap/{snap_name}/current/.config",
            f"snap/{snap_name}/current/.cache",
            f"snap/{snap_name}/common/.config",
            f"snap/{snap_name}/common/.cache",
        ))

    errors = []
    home = home.resolve()
    for relative_path in paths:
        candidate = home / relative_path
        try:
            resolved = candidate.resolve()
            if os.path.commonpath((str(home), str(resolved))) != str(home):
                errors.append(f"refused path outside home: {relative_path}")
                continue
            if candidate.is_symlink():
                candidate.unlink()
            elif candidate.is_dir():
                shutil.rmtree(candidate)
            elif candidate.exists():
                candidate.unlink()
        except OSError as error:
            errors.append(f"{relative_path}: {error}")
    return errors


def run_install(app_names, manual_install_data=None):
    manual_install_data = manual_install_data or {}
    manual_paths = manual_install_data.get("paths", {})
    progress_total = int(manual_install_data.get("progress_total", len(app_names)))
    completed_apps = set()

    def emit_progress(event, **details):
        print(
            "DEEZ_PROGRESS " + json.dumps({
                "event": event,
                "completed": len(completed_apps),
                "total": progress_total,
                **details,
            }),
            file=sys.stderr,
            flush=True,
        )

    def complete_app(app_name):
        if app_name not in completed_apps:
            completed_apps.add(app_name)
            emit_progress("app_complete", app=app_name)

    emit_progress("started")
    maintenance_results = {}
    unknown_apps = set(app_names) - (
        set(APT_PACKAGES)
        | set(SNAP_PACKAGES)
        | set(FLATPAK_APPS)
        | set(UNAVAILABLE_APPS)
        | MANUAL_INSTALL_APPS
    )
    if unknown_apps:
        raise ValueError(f"Unsupported apps: {', '.join(sorted(unknown_apps))}")

    if manual_install_data.get("remove_deprecated_appimagelauncher_ppa"):
        try:
            ppa_check = subprocess.run(
                [
                    "grep",
                    "-R",
                    "-l",
                    "-F",
                    "appimagelauncher-team/stable",
                    "/etc/apt/sources.list.d",
                ],
                check=False,
                capture_output=True,
                text=True,
            )
            if ppa_check.returncode == 0:
                subprocess.run(
                    [
                        "add-apt-repository",
                        "--remove",
                        "--yes",
                        "ppa:appimagelauncher-team/stable",
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
                maintenance_results["appimagelauncher_ppa"] = "removed"
            elif ppa_check.returncode != 1:
                raise subprocess.CalledProcessError(
                    ppa_check.returncode,
                    ppa_check.args,
                    stderr=ppa_check.stderr,
                )
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            maintenance_results["appimagelauncher_ppa"] = (
                f"could not remove deprecated source ({detail.strip()})"
            )

    results = {
        name: UNAVAILABLE_APPS[name]
        for name in app_names
        if name in UNAVAILABLE_APPS
    }
    for name in results:
        complete_app(name)
    apt_apps = [name for name in app_names if name in APT_PACKAGES]
    if any(name in FLATPAK_APPS for name in app_names) and "Flatpak" not in apt_apps:
        apt_apps.append("Flatpak")

    apt_packages = [
        APT_PACKAGES[name] for name in apt_apps
    ]
    apt_app_names = list(apt_apps)

    manual_apt_packages = {
        "Bauh": ["pipx", "python3-gi", "gir1.2-gtk-3.0"],
        "Topgrade": ["cargo"],
        "Homebrew": ["build-essential", "procps", "curl", "file", "git"],
    }
    for name, packages in manual_apt_packages.items():
        if name in app_names:
            apt_app_names.append(name)
            apt_packages.extend(packages)

    if "Google Chrome" in app_names:
        chrome_package = manual_paths.get("google_chrome_deb")
        if chrome_package:
            apt_app_names.append("Google Chrome")
            apt_packages.append(chrome_package)
        else:
            results["Google Chrome"] = "installation failed (downloaded package is missing)"

    if "Piper" in app_names:
        apt_packages.append("ratbagd")

    if apt_packages:
        emit_progress("phase", message="Installing system packages")
        try:
            apt_command = [
                "apt-get",
                "install",
                "-y",
                "--no-install-recommends",
                "-o",
                "APT::Status-Fd=1",
                *apt_packages,
            ]
            if "OBS Studio" in app_names:
                apt_command.append("obs-plugins")
            apt_process = subprocess.Popen(
                apt_command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            apt_output = []
            for line in apt_process.stdout:
                if line.startswith("pmstatus:"):
                    status_parts = line.rstrip().split(":", 3)
                    if len(status_parts) >= 3:
                        try:
                            package_percentage = float(status_parts[2])
                        except ValueError:
                            continue
                        emit_progress(
                            "batch_progress",
                            percent=package_percentage,
                            stage="install",
                            batch_count=len(apt_app_names),
                            message=(
                                status_parts[3]
                                if len(status_parts) > 3
                                else "Installing system packages"
                            ),
                        )
                elif line.startswith("dlstatus:"):
                    status_parts = line.rstrip().split(":")
                    if len(status_parts) >= 7:
                        try:
                            download_percentage = float(status_parts[-3])
                        except ValueError:
                            continue
                        emit_progress(
                            "batch_download",
                            percent=download_percentage,
                            stage="download",
                            batch_count=len(apt_app_names),
                            message=status_parts[-4] or "Downloading system packages",
                        )
                else:
                    apt_output.append(line)
            apt_returncode = apt_process.wait()
            if apt_returncode:
                raise subprocess.CalledProcessError(
                    apt_returncode,
                    apt_command,
                    output="".join(apt_output),
                )
            for name in apt_app_names:
                results[name] = (
                    "ready for user setup"
                    if name in {"Bauh", "Topgrade", "Homebrew"}
                    else "installed"
                )
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            for name in apt_app_names:
                results[name] = f"installation failed ({detail.strip()})"
            if "Piper" in app_names:
                results["Piper"] = (
                    "installation failed: could not install ratbagd "
                    f"dependency ({detail.strip()})"
                )
        for name in apt_app_names:
            if name not in {"Bauh", "Topgrade", "Homebrew"}:
                complete_app(name)
    if "Homebrew" in app_names and results.get("Homebrew") == "ready for user setup":
        try:
            subprocess.run(
                [
                    "install",
                    "-d",
                    "-o",
                    str(manual_install_data["uid"]),
                    "-g",
                    str(manual_install_data["gid"]),
                    "/home/linuxbrew/.linuxbrew",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
        except (KeyError, OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            results["Homebrew"] = f"installation failed ({detail.strip()})"

    if "Pacstall" in app_names:
        emit_progress("phase", message="Installing Pacstall")
        installer_path = manual_paths.get("pacstall_installer")
        if installer_path:
            try:
                subprocess.run(
                    ["bash", installer_path],
                    check=True,
                    capture_output=True,
                    text=True,
                    input="n\n",
                )
                results["Pacstall"] = "installed"
            except (OSError, subprocess.CalledProcessError) as error:
                detail = getattr(error, "stderr", None) or str(error)
                results["Pacstall"] = f"installation failed ({detail.strip()})"
        else:
            results["Pacstall"] = "installation failed (installer file is missing)"
        complete_app("Pacstall")

    snap_apps = [name for name in app_names if name in SNAP_PACKAGES]
    for name in snap_apps:
        emit_progress("phase", message=f"Installing {name}")
        try:
            subprocess.run(
                ["snap", "install", *SNAP_PACKAGES[name]],
                check=True,
                capture_output=True,
                text=True,
            )
            results[name] = "installed"
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            results[name] = f"installation failed ({detail.strip()})"
        complete_app(name)

    flatpak_apps = [name for name in app_names if name in FLATPAK_APPS]
    if flatpak_apps:
        emit_progress("phase", message="Preparing Flathub")
        try:
            subprocess.run(
                [
                    "flatpak",
                    "remote-add",
                    "--system",
                    "--if-not-exists",
                    "flathub",
                    "https://flathub.org/repo/flathub.flatpakrepo",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            for name in flatpak_apps:
                if name in results:
                    continue
                results[name] = (
                    f"installation failed: could not configure Flathub "
                    f"({detail.strip()})"
                )
                complete_app(name)
        else:
            for name in flatpak_apps:
                if name in results:
                    continue
                emit_progress("phase", message=f"Installing {name}")
                try:
                    subprocess.run(
                        [
                            "flatpak",
                            "install",
                            "--system",
                            "--assumeyes",
                            "flathub",
                            FLATPAK_APPS[name],
                        ],
                        check=True,
                        capture_output=True,
                        text=True,
                    )
                    results[name] = (
                        "installed with ratbagd" if name == "Piper"
                        else "installed"
                    )
                    if name == "Sunshine":
                        try:
                            subprocess.run(
                                [
                                    "flatpak",
                                    "run",
                                    "--command=additional-install.sh",
                                    FLATPAK_APPS[name],
                                ],
                                check=True,
                                capture_output=True,
                                text=True,
                            )
                        except (OSError, subprocess.CalledProcessError) as error:
                            detail = getattr(error, "stderr", None) or str(error)
                            results[name] = (
                                "installed, but additional setup failed "
                                f"({detail.strip()})"
                            )
                except (OSError, subprocess.CalledProcessError) as error:
                    detail = getattr(error, "stderr", None) or str(error)
                    results[name] = f"installation failed ({detail.strip()})"
                complete_app(name)

    for name in app_names:
        if name not in {"Bauh", "Topgrade", "Homebrew"}:
            complete_app(name)

    output = {
        name: results.get(name, "installation failed (no result returned)")
        for name in app_names
    }
    if maintenance_results:
        output["__maintenance__"] = maintenance_results
    print(json.dumps(output))


def run_uninstall(app_names, user_uid=None):
    results = {}
    apt_apps = [name for name in app_names if name in APT_PACKAGES]
    snap_apps = [name for name in app_names if name in SNAP_PACKAGES]
    flatpak_apps = [name for name in app_names if name in FLATPAK_APPS]
    unsupported_apps = set(app_names) - (
        set(APT_PACKAGES)
        | set(SNAP_PACKAGES)
        | set(FLATPAK_APPS)
        | set(USER_UNINSTALL_COMMANDS)
    )
    for name in unsupported_apps:
        results[name] = "no automatic system uninstaller is configured"

    def error_text(error):
        return (
            getattr(error, "stderr", None)
            or getattr(error, "stdout", None)
            or str(error)
        ).strip()

    def run_as_user(command, user):
        user_home = Path(user.pw_dir)
        user_path = os.pathsep.join((
            os.environ.get("PATH", ""),
            str(user_home / ".local/bin"),
            str(user_home / ".cargo/bin"),
        ))
        return subprocess.run(
            [
                "runuser",
                "--user",
                user.pw_name,
                "--",
                "env",
                f"HOME={user_home}",
                f"USER={user.pw_name}",
                f"LOGNAME={user.pw_name}",
                f"PATH={user_path}",
                *command,
            ],
            check=True,
            capture_output=True,
            text=True,
        )

    def purge_apt_app(name):
        package = APT_PACKAGES[name]
        try:
            status = subprocess.run(
                ["dpkg-query", "-W", "-f=${db:Status-Abbrev}", package],
                check=False,
                capture_output=True,
                text=True,
            )
            if status.returncode != 0 or not status.stdout.startswith("ii "):
                results[name] = "not installed; user settings and cache cleaned"
                return
            subprocess.run(
                ["apt-get", "purge", "-y", package],
                check=True,
                capture_output=True,
                text=True,
            )
            results[name] = "uninstalled and purged"
        except (OSError, subprocess.CalledProcessError) as error:
            results[name] = f"uninstallation failed ({error_text(error)})"

    for name in apt_apps:
        if name != "Flatpak":
            purge_apt_app(name)

    for name in snap_apps:
        try:
            installed = subprocess.run(
                ["snap", "list", SNAP_NAMES[name]],
                check=False,
                capture_output=True,
                text=True,
            )
            if installed.returncode != 0:
                results[name] = "not installed; user settings and cache cleaned"
                continue
            subprocess.run(
                ["snap", "remove", SNAP_NAMES[name]],
                check=True,
                capture_output=True,
                text=True,
            )
            results[name] = (
                "uninstalled; Snap may retain a recovery snapshot"
            )
        except (OSError, subprocess.CalledProcessError) as error:
            results[name] = f"uninstallation failed ({error_text(error)})"

    for name in flatpak_apps:
        try:
            subprocess.run(
                [
                    "flatpak",
                    "uninstall",
                    "--system",
                    "--assumeyes",
                    FLATPAK_APPS[name],
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            results[name] = "uninstalled"
        except (OSError, subprocess.CalledProcessError) as error:
            detail = error_text(error)
            if "No installed refs found" not in detail:
                results[name] = f"uninstallation failed ({detail})"
                continue
            try:
                if user_uid is None:
                    raise ValueError("The logged-in user could not be determined")
                user = pwd.getpwuid(int(user_uid))
                run_as_user(
                    [
                        "flatpak",
                        "uninstall",
                        "--user",
                        "--assumeyes",
                        FLATPAK_APPS[name],
                    ],
                    user,
                )
                results[name] = "uninstalled"
            except (
                KeyError,
                TypeError,
                ValueError,
                OSError,
                subprocess.CalledProcessError,
            ) as user_error:
                user_detail = error_text(user_error)
                if "No installed refs found" in user_detail:
                    results[name] = (
                        "not installed; user settings and cache cleaned"
                    )
                else:
                    results[name] = (
                        f"uninstallation failed ({user_detail})"
                    )

    if "Flatpak" in apt_apps:
        purge_apt_app("Flatpak")

    if user_uid is not None:
        try:
            user = pwd.getpwuid(int(user_uid))
        except (KeyError, TypeError, ValueError) as error:
            user = None
            for name in USER_UNINSTALL_COMMANDS:
                if name in app_names:
                    results[name] = f"uninstallation failed ({error})"
        if user is not None:
            for name, command in USER_UNINSTALL_COMMANDS.items():
                if name not in app_names:
                    continue
                try:
                    run_as_user(command, user)
                    results[name] = "uninstalled"
                except (OSError, subprocess.CalledProcessError) as error:
                    detail = error_text(error)
                    if "not installed" in detail.lower():
                        results[name] = (
                            "not installed; user settings and cache cleaned"
                        )
                    else:
                        results[name] = f"uninstallation failed ({detail})"

    if user_uid is not None:
        try:
            user = pwd.getpwuid(int(user_uid))
            home = Path(user.pw_dir)
            if not home.is_dir():
                raise OSError(f"User home does not exist: {home}")
        except (KeyError, TypeError, ValueError, OSError) as error:
            for name in app_names:
                if name in results and results[name].startswith("uninstallation failed"):
                    continue
                results[name] = f"settings cleanup failed ({error})"
        else:
            for name in app_names:
                cleanup_errors = remove_user_settings(name, home)
                if cleanup_errors:
                    previous = results.get(name, "uninstalled")
                    results[name] = (
                        f"{previous}; settings cleanup incomplete: "
                        + "; ".join(cleanup_errors)
                    )
                elif (
                    name in results
                    and not results[name].startswith("uninstallation failed")
                    and "settings and cache cleaned" not in results[name]
                ):
                    results[name] = (
                        f"{results[name]}; user settings and cache cleaned"
                    )
                elif name not in results:
                    if name in MANUAL_INSTALL_APPS:
                        results[name] = (
                            "user settings and cache cleaned; no automatic "
                            "app uninstaller is configured"
                        )
                    else:
                        results[name] = "user settings and cache cleaned"

    print(json.dumps({
        name: results.get(name, "uninstallation failed (no result returned)")
        for name in app_names
    }))


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--request-file":
        with open(sys.argv[2], encoding="utf-8") as request_file:
            request = json.load(request_file)
        run_install(request["apps"], request.get("manual_install_data"))
    elif len(sys.argv) == 3 and sys.argv[1] == "--uninstall-request-file":
        with open(sys.argv[2], encoding="utf-8") as request_file:
            request = json.load(request_file)
        run_uninstall(request["apps"], request.get("uid"))
    else:
        run_install(sys.argv[1:])
