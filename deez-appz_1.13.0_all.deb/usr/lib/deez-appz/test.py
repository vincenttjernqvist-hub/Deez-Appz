import importlib.util
import json
import math
import os
import pwd
import shutil
import subprocess
import sys
import tempfile
import urllib.request

if importlib.util.find_spec("tkinter") is None:
    if shutil.which("apt-get") is None:
        sys.exit("Tkinter is missing and this system does not use Ubuntu's package manager.")

    print("Tkinter is missing. Installing it...")
    subprocess.run(["pkexec", "apt-get", "update"], check=True)
    subprocess.run(
        ["pkexec", "apt-get", "install", "-y", "python3-tk"],
        check=True
    )

import tkinter as tk
from tkinter import messagebox, ttk

root = tk.Tk()
root.title("Deez Appz")
root.geometry("1000x760")
root.minsize(640, 480)
root.configure(bg="white")

app_canvas = tk.Canvas(root, bg="white", highlightthickness=0)
app_scrollbar = ttk.Scrollbar(
    root,
    orient="vertical",
    command=app_canvas.yview,
)
app_canvas.configure(yscrollcommand=app_scrollbar.set)
app_scrollbar.pack(side="right", fill="y")
app_canvas.pack(side="left", fill="both", expand=True)
app_content = tk.Frame(app_canvas, bg="white")
app_content_window = app_canvas.create_window(
    (0, 0),
    window=app_content,
    anchor="nw",
)


def update_scroll_region(_event=None):
    app_canvas.configure(scrollregion=app_canvas.bbox("all"))


def resize_app_content(event):
    app_canvas.itemconfigure(app_content_window, width=event.width)


def scroll_app(event):
    if event.num == 4:
        app_canvas.yview_scroll(-1, "units")
    elif event.num == 5:
        app_canvas.yview_scroll(1, "units")
    elif event.delta:
        app_canvas.yview_scroll(int(-event.delta / 120), "units")


app_content.bind("<Configure>", update_scroll_region)
app_canvas.bind("<Configure>", resize_app_content)
app_canvas.bind_all("<MouseWheel>", scroll_app)
app_canvas.bind_all("<Button-4>", scroll_app)
app_canvas.bind_all("<Button-5>", scroll_app)


def build_app_icon():
    icon = tk.PhotoImage(width=64, height=64)

    def set_pixel(x, y, color):
        if 0 <= x < 64 and 0 <= y < 64:
            icon.put(color, (x, y))

    def fill_circle(cx, cy, r, color):
        for y in range(max(0, cy - r), min(64, cy + r + 1)):
            for x in range(max(0, cx - r), min(64, cx + r + 1)):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                    set_pixel(x, y, color)

    def draw_ring(cx, cy, outer_r, inner_r, color):
        fill_circle(cx, cy, outer_r, color)
        fill_circle(cx, cy, inner_r, "#1c4f7d")

    def draw_tooth(cx, cy, radius, angle_deg, length=8, width=5, color="#2d9bd3"):
        angle = math.radians(angle_deg)
        for step in range(length):
            tx = int(round(cx + math.cos(angle) * (radius + step)))
            ty = int(round(cy + math.sin(angle) * (radius + step)))
            for dx in range(-width, width + 1):
                for dy in range(-width, width + 1):
                    if dx * dx + dy * dy <= width * width:
                        set_pixel(tx + dx, ty + dy, color)

    def fill_polygon(points, color):
        min_x = min(p[0] for p in points)
        max_x = max(p[0] for p in points)
        min_y = min(p[1] for p in points)
        max_y = max(p[1] for p in points)

        for y in range(max(0, min_y), min(64, max_y + 1)):
            for x in range(max(0, min_x), min(64, max_x + 1)):
                inside = False
                for index, point in enumerate(points):
                    x1, y1 = point
                    x2, y2 = points[(index + 1) % len(points)]
                    intersects = ((y1 > y) != (y2 > y)) and (
                        x < (x2 - x1) * (y - y1) / (y2 - y1) + x1
                    )
                    if intersects:
                        inside = not inside
                if inside:
                    set_pixel(x, y, color)

    for y in range(64):
        for x in range(64):
            dx = x - 32
            dy = y - 32
            if abs(dx) < 30 and abs(dy) < 30:
                r = min(1.0, 1.0 - (abs(dx) + abs(dy)) / 80)
                c1 = (22, 90, 148)
                c2 = (54, 191, 216)
                r1, g1, b1 = c1
                r2, g2, b2 = c2
                red = int(r1 + (r2 - r1) * (1 - (abs(dx) + abs(dy)) / 80))
                green = int(g1 + (g2 - g1) * (1 - (abs(dx) + abs(dy)) / 80))
                blue = int(b1 + (b2 - b1) * (1 - (abs(dx) + abs(dy)) / 80))
                icon.put(f'#{red:02x}{green:02x}{blue:02x}', (x, y))
            else:
                icon.put("#0b3a6d", (x, y))

    draw_ring(32, 32, 24, 12, "#4ec9d1")
    draw_ring(32, 32, 20, 14, "#1d5d8a")
    for angle in range(0, 360, 30):
        draw_tooth(32, 32, 24, angle, 8, 4, "#5fc7e8")

    fill_circle(32, 32, 8, "#2f9ad1")

    shaft_color = "#d7f4ff"
    fill_circle(32, 32, 4, shaft_color)

    arrow_points = [
        (32, 18),
        (22, 36),
        (28, 36),
        (28, 52),
        (36, 52),
        (36, 36),
        (42, 36),
    ]
    fill_polygon(arrow_points, "#a8f3ff")
    fill_polygon([(32, 18), (29, 12), (35, 12)], "#c9fbff")

    for x in range(8, 57):
        for y in range(58, 64):
            if (x - 32) ** 2 + (y - 61) ** 2 <= 7 ** 2:
                icon.put("#dffbff", (x, y))

    return icon


app_icon = build_app_icon()
root.iconphoto(True, app_icon)


def set_status(message):
    status_text.configure(state="normal")
    status_text.delete("1.0", "end")
    status_text.insert("end", message)
    status_text.see("end")
    status_text.configure(state="disabled")


def uninstall_deez_app():
    try:
        package_status = subprocess.run(
            [
                "dpkg-query",
                "-W",
                "-f=${db:Status-Abbrev}",
                "deez-appz",
            ],
            check=False,
            capture_output=True,
            text=True,
        )
    except OSError as error:
        messagebox.showerror(
            "Unable to check installation",
            f"Could not check whether Deez Appz is installed: {error}",
            parent=root,
        )
        return

    if package_status.returncode != 0 or not package_status.stdout.startswith("ii "):
        messagebox.showinfo(
            "Deez Appz is not installed as a package",
            "This copy of Deez Appz was not installed as a Debian package, "
            "so it cannot remove itself safely. No files were changed.",
            parent=root,
        )
        return

    if not messagebox.askyesno(
        "Uninstall Deez Appz",
        "Remove Deez Appz from this computer? The app will close after "
        "uninstallation. Your project files and downloaded app packages "
        "will not be removed.",
        parent=root,
    ):
        return

    set_status("Uninstalling Deez Appz...")
    root.update_idletasks()
    try:
        subprocess.run(
            ["pkexec", "apt-get", "remove", "-y", "deez-appz"],
            check=True,
        )
    except (OSError, subprocess.CalledProcessError) as error:
        set_status(f"Could not uninstall Deez Appz ({error})")
        messagebox.showerror(
            "Uninstallation failed",
            f"Deez Appz could not be uninstalled: {error}",
            parent=root,
        )
        return

    root.destroy()


def install_selected_apps():
    selected_apps = [
        app_name for app_name, selected in app_selections.items()
        if selected.get()
    ]
    if not selected_apps:
        set_status("Select at least one app to install.")
        return

    game_app_names = {
        "Steam",
        "Lutris",
        "Heroic Games Launcher",
        "Discord",
        "ProtonUp-Qt",
        "MangoHud",
        "Goverlay",
        "Bottles",
        "Prism Launcher",
        "RetroArch",
        "Itch.io",
        "Piper",
        "GameMode",
        "Sunshine",
        "Moonlight",
        "OBS Studio",
        "Cartridges",
        "CoreCtrl",
        "Oversteer",
        "Greenlight",
    }
    communication_app_names = {
        "Discord",
        "Element",
        "Slack",
        "Microsoft Teams",
        "Session",
        "Revolt",
        "Mumble",
        "TeamSpeak",
        "Caprine",
        "Fractal",
        "FluffyChat",
        "Zoom",
        "Skype",
        "Mattermost",
        "Zulip",
        "SimpleX Chat",
        "qTox",
        "Threema",
        "Wire",
        "Guilded",
        "Jitsi Meet",
        "Telegram",
        "Signal",
    }
    batch_app_names = game_app_names | communication_app_names
    selected_batch_apps = [
        app_name for app_name in selected_apps if app_name in batch_app_names
    ]

    def install_google_chrome():
        with tempfile.TemporaryDirectory() as temp_dir:
            package_path = os.path.join(temp_dir, "google-chrome.deb")
            with urllib.request.urlopen(
                "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb",
                timeout=60,
            ) as response, open(package_path, "wb") as package:
                shutil.copyfileobj(response, package)
            subprocess.run(
                ["pkexec", "apt-get", "install", "-y", package_path],
                check=True,
            )

    def install_pacstall():
        with tempfile.TemporaryDirectory() as temp_dir:
            installer_path = os.path.join(temp_dir, "pacstall-installer")
            with urllib.request.urlopen(
                "https://pacstall.dev/q/pacstall",
                timeout=60,
            ) as response, open(installer_path, "wb") as installer:
                shutil.copyfileobj(response, installer)
            subprocess.run(["pkexec", "bash", installer_path], check=True)

    def install_bauh():
        subprocess.run(
            [
                "pkexec",
                "apt-get",
                "install",
                "-y",
                "pipx",
                "python3-gi",
                "gir1.2-gtk-3.0",
            ],
            check=True,
        )
        subprocess.run(
            ["pipx", "install", "--system-site-packages", "bauh"],
            check=True,
        )

    def install_topgrade():
        subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "cargo"],
            check=True,
        )
        subprocess.run(["cargo", "install", "--locked", "topgrade"], check=True)

    def install_flatpak_app(app_id):
        subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "flatpak"],
            check=True,
        )
        subprocess.run(
            [
                "pkexec",
                "flatpak",
                "remote-add",
                "--system",
                "--if-not-exists",
                "flathub",
                "https://flathub.org/repo/flathub.flatpakrepo",
            ],
            check=True,
        )
        subprocess.run(
            [
                "pkexec",
                "flatpak",
                "install",
                "--system",
                "--assumeyes",
                "flathub",
                app_id,
            ],
            check=True,
        )

    def install_sunshine():
        app_id = "dev.lizardbyte.app.Sunshine"
        install_flatpak_app(app_id)
        subprocess.run(
            [
                "flatpak",
                "run",
                "--command=additional-install.sh",
                app_id,
            ],
            check=True,
        )

    def install_appimagelauncher():
        subprocess.run(
            [
                "pkexec",
                "apt-get",
                "install",
                "-y",
                "software-properties-common",
            ],
            check=True,
        )
        subprocess.run(
            [
                "pkexec",
                "add-apt-repository",
                "-y",
                "ppa:appimagelauncher-team/stable",
            ],
            check=True,
        )
        subprocess.run(["pkexec", "apt-get", "update"], check=True)
        subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "appimagelauncher"],
            check=True,
        )

    def install_homebrew():
        subprocess.run(
            [
                "pkexec",
                "apt-get",
                "install",
                "-y",
                "build-essential",
                "procps",
                "curl",
                "file",
                "git",
            ],
            check=True,
        )
        user = pwd.getpwuid(os.getuid())
        subprocess.run(
            [
                "pkexec",
                "install",
                "-d",
                "-o",
                str(user.pw_uid),
                "-g",
                str(user.pw_gid),
                "/home/linuxbrew/.linuxbrew",
            ],
            check=True,
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            installer_path = os.path.join(temp_dir, "homebrew-installer")
            with urllib.request.urlopen(
                "https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh",
                timeout=60,
            ) as response, open(installer_path, "wb") as installer:
                shutil.copyfileobj(response, installer)
            subprocess.run(
                ["/bin/bash", installer_path],
                check=True,
                env={**os.environ, "NONINTERACTIVE": "1"},
            )

    installers = {
        "Visual Studio Code": lambda: subprocess.run(
            ["pkexec", "snap", "install", "code", "--classic"], check=True
        ),
        "Spotify": lambda: subprocess.run(
            ["pkexec", "snap", "install", "spotify"], check=True
        ),
        "Blender": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "blender"], check=True
        ),
        "KiCad": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "kicad"], check=True
        ),
        "Krita": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "krita"], check=True
        ),
        "Google Chrome": install_google_chrome,
        "Brave": lambda: subprocess.run(
            ["pkexec", "snap", "install", "brave"], check=True
        ),
        "Discord": lambda: subprocess.run(
            ["pkexec", "snap", "install", "discord"], check=True
        ),
        "Bauh": install_bauh,
        "Topgrade": install_topgrade,
        "Flatpak": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "flatpak"], check=True
        ),
        "Snapcraft": lambda: subprocess.run(
            ["pkexec", "snap", "install", "snapcraft", "--classic"], check=True
        ),
        "AppImageLauncher": install_appimagelauncher,
        "Warehouse": lambda: install_flatpak_app("io.github.flattool.Warehouse"),
        "GNOME Software": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "gnome-software"], check=True
        ),
        "KDE Discover": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "plasma-discover"], check=True
        ),
        "Synaptic": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "synaptic"], check=True
        ),
        "Pacstall": install_pacstall,
        "Homebrew": install_homebrew,
        "Nix": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "nix-bin"], check=True
        ),
        "Distrobox": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "distrobox"], check=True
        ),
        "Chezmoi": lambda: subprocess.run(
            ["pkexec", "snap", "install", "chezmoi"], check=True
        ),
        "Ansible": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "ansible"], check=True
        ),
        "VLC": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "vlc"], check=True
        ),
        "Firefox": lambda: subprocess.run(
            ["pkexec", "snap", "install", "firefox"], check=True
        ),
        "LibreOffice": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "libreoffice"], check=True
        ),
        "OnlyOffice": lambda: install_flatpak_app(
            "org.onlyoffice.desktopeditors"
        ),
        "Bitwarden": lambda: install_flatpak_app("com.bitwarden.desktop"),
        "Telegram": lambda: subprocess.run(
            ["pkexec", "snap", "install", "telegram-desktop"], check=True
        ),
        "Signal": lambda: install_flatpak_app("org.signal.Signal"),
        "Steam": lambda: install_flatpak_app("com.valvesoftware.Steam"),
        "ProtonUp-Qt": lambda: install_flatpak_app("net.davidotek.pupgui2"),
        "MangoHud": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "mangohud"], check=True
        ),
        "Goverlay": lambda: install_flatpak_app(
            "io.github.benjamimgois.goverlay"
        ),
        "Bottles": lambda: install_flatpak_app("com.usebottles.bottles"),
        "Prism Launcher": lambda: install_flatpak_app(
            "org.prismlauncher.PrismLauncher"
        ),
        "RetroArch": lambda: install_flatpak_app("org.libretro.RetroArch"),
        "Itch.io": lambda: install_flatpak_app("io.itch.itch"),
        "Piper": lambda: install_flatpak_app("org.freedesktop.Piper"),
        "GameMode": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "gamemode"], check=True
        ),
        "Sunshine": install_sunshine,
        "Moonlight": lambda: install_flatpak_app(
            "com.moonlight_stream.Moonlight"
        ),
        "Cartridges": lambda: install_flatpak_app("page.kramo.Cartridges"),
        "CoreCtrl": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "corectrl"], check=True
        ),
        "Oversteer": lambda: install_flatpak_app(
            "io.github.berarma.Oversteer"
        ),
        "Greenlight": lambda: install_flatpak_app(
            "io.github.unknownskl.greenlight"
        ),
        "OBS Studio": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "obs-studio"], check=True
        ),
        "GIMP": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "gimp"], check=True
        ),
        "Obsidian": lambda: install_flatpak_app("md.obsidian.Obsidian"),
        "Flameshot": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "flameshot"], check=True
        ),
        "Thunderbird": lambda: subprocess.run(
            ["pkexec", "snap", "install", "thunderbird"], check=True
        ),
        "Transmission": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "transmission-gtk"], check=True
        ),
        "Lutris": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "lutris"], check=True
        ),
        "Heroic Games Launcher": lambda: install_flatpak_app(
            "com.heroicgameslauncher.hgl"
        ),
    }
    results = []
    if selected_batch_apps:
        set_status(
            "Installing selected apps (one authorization prompt)..."
        )
        root.update_idletasks()
        worker_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "install_worker.py",
        )
        try:
            worker_result = subprocess.run(
                [
                    "pkexec",
                    sys.executable,
                    worker_path,
                    *selected_batch_apps,
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            game_results = json.loads(worker_result.stdout)
            results.extend(
                f"{app_name}: {game_results[app_name]}"
                for app_name in selected_batch_apps
            )
        except (OSError, subprocess.CalledProcessError, json.JSONDecodeError) as error:
            results.extend(
                f"{app_name}: installation failed ({error})"
                for app_name in selected_batch_apps
            )

    for app_name in selected_apps:
        if app_name in batch_app_names:
            continue
        set_status(f"Installing {app_name}...")
        root.update_idletasks()
        try:
            installers[app_name]()
            results.append(f"{app_name}: installed")
        except (OSError, subprocess.CalledProcessError) as error:
            results.append(f"{app_name}: installation failed ({error})")

    set_status("\n".join(results))


def uninstall_selected_apps():
    selected_apps = [
        app_name for app_name, selected in app_selections.items()
        if selected.get()
    ]
    if not selected_apps:
        set_status("Select at least one app to uninstall.")
        return
    if not messagebox.askyesno(
        "Confirm uninstall",
        "Uninstall the selected apps? App data and settings are not "
        "intentionally removed.",
        parent=root,
    ):
        return
    if "Flatpak" in selected_apps:
        selected_apps.remove("Flatpak")
        selected_apps.append("Flatpak")

    apt_packages = {
        "Blender": "blender",
        "KiCad": "kicad",
        "Krita": "krita",
        "Google Chrome": "google-chrome-stable",
        "Flatpak": "flatpak",
        "AppImageLauncher": "appimagelauncher",
        "GNOME Software": "gnome-software",
        "KDE Discover": "plasma-discover",
        "Synaptic": "synaptic",
        "Nix": "nix-bin",
        "Distrobox": "distrobox",
        "Ansible": "ansible",
        "VLC": "vlc",
        "LibreOffice": "libreoffice",
        "OBS Studio": "obs-studio",
        "GIMP": "gimp",
        "Flameshot": "flameshot",
        "Transmission": "transmission-gtk",
        "MangoHud": "mangohud",
        "GameMode": "gamemode",
        "CoreCtrl": "corectrl",
    }
    snap_packages = {
        "Visual Studio Code": "code",
        "Spotify": "spotify",
        "Brave": "brave",
        "Discord": "discord",
        "Snapcraft": "snapcraft",
        "Chezmoi": "chezmoi",
        "Firefox": "firefox",
        "Telegram": "telegram-desktop",
        "Thunderbird": "thunderbird",
    }
    flatpak_apps = {
        "Element": "im.riot.Riot",
        "Slack": "com.slack.Slack",
        "Microsoft Teams": "com.github.IsmaelMartinez.teams_for_linux",
        "Session": "network.loki.Session",
        "Mumble": "info.mumble.Mumble",
        "TeamSpeak": "com.teamspeak.TeamSpeak",
        "Caprine": "com.sindresorhus.Caprine",
        "Fractal": "org.gnome.Fractal",
        "FluffyChat": "im.fluffychat.Fluffychat",
        "Zoom": "us.zoom.Zoom",
        "Mattermost": "com.mattermost.Desktop",
        "Zulip": "org.zulip.Zulip",
        "SimpleX Chat": "chat.simplex.simplex",
        "qTox": "io.github.qtox.qTox",
        "Lutris": "net.lutris.Lutris",
        "Warehouse": "io.github.flattool.Warehouse",
        "OnlyOffice": "org.onlyoffice.desktopeditors",
        "Bitwarden": "com.bitwarden.desktop",
        "Signal": "org.signal.Signal",
        "Steam": "com.valvesoftware.Steam",
        "ProtonUp-Qt": "net.davidotek.pupgui2",
        "Goverlay": "io.github.benjamimgois.goverlay",
        "Bottles": "com.usebottles.bottles",
        "Prism Launcher": "org.prismlauncher.PrismLauncher",
        "RetroArch": "org.libretro.RetroArch",
        "Itch.io": "io.itch.itch",
        "Piper": "org.freedesktop.Piper",
        "Sunshine": "dev.lizardbyte.app.Sunshine",
        "Moonlight": "com.moonlight_stream.Moonlight",
        "Cartridges": "page.kramo.Cartridges",
        "Oversteer": "io.github.berarma.Oversteer",
        "Greenlight": "io.github.unknownskl.greenlight",
        "Obsidian": "md.obsidian.Obsidian",
        "Heroic Games Launcher": "com.heroicgameslauncher.hgl",
    }

    def remove_apt_package(package_name):
        subprocess.run(
            ["pkexec", "apt-get", "remove", "-y", package_name],
            check=True,
        )

    def remove_snap_package(package_name):
        subprocess.run(["pkexec", "snap", "remove", package_name], check=True)

    def remove_flatpak_app(app_id):
        subprocess.run(
            [
                "pkexec",
                "flatpak",
                "uninstall",
                "--system",
                "--assumeyes",
                app_id,
            ],
            check=True,
        )

    uninstallers = {
        **{
            app_name: lambda package=package: remove_apt_package(package)
            for app_name, package in apt_packages.items()
        },
        **{
            app_name: lambda package=package: remove_snap_package(package)
            for app_name, package in snap_packages.items()
        },
        **{
            app_name: lambda app_id=app_id: remove_flatpak_app(app_id)
            for app_name, app_id in flatpak_apps.items()
        },
        "Bauh": lambda: subprocess.run(["pipx", "uninstall", "bauh"], check=True),
        "Topgrade": lambda: subprocess.run(
            ["cargo", "uninstall", "topgrade"],
            check=True,
        ),
    }

    results = []
    for app_name in selected_apps:
        uninstaller = uninstallers.get(app_name)
        if uninstaller is None:
            results.append(
                f"{app_name}: no automatic uninstaller is available."
            )
            continue

        set_status(f"Uninstalling {app_name}...")
        root.update_idletasks()
        try:
            uninstaller()
            results.append(f"{app_name}: uninstalled")
        except (OSError, subprocess.CalledProcessError) as error:
            results.append(f"{app_name}: uninstallation failed ({error})")

    set_status("\n".join(results))


app_categories = {
    "Webb och internet": (
        "Google Chrome",
        "Brave",
        "Firefox",
        "Thunderbird",
        "Transmission",
    ),
    "Kontor och produktivitet": (
        "LibreOffice",
        "OnlyOffice",
        "Obsidian",
        "Bitwarden",
    ),
    "Kommunikation": (
        "Discord",
        "Element",
        "Slack",
        "Microsoft Teams",
        "Session",
        "Revolt",
        "Mumble",
        "TeamSpeak",
        "Caprine",
        "Fractal",
        "FluffyChat",
        "Zoom",
        "Skype",
        "Mattermost",
        "Zulip",
        "SimpleX Chat",
        "qTox",
        "Threema",
        "Wire",
        "Guilded",
        "Jitsi Meet",
        "Telegram",
        "Signal",
    ),
    "Media och kreativt": (
        "Spotify",
        "VLC",
        "GIMP",
        "Krita",
        "Blender",
        "Flameshot",
    ),
    "Spel": (
        "Steam",
        "Lutris",
        "Heroic Games Launcher",
        "ProtonUp-Qt",
        "MangoHud",
        "Goverlay",
        "Bottles",
        "Prism Launcher",
        "RetroArch",
        "Itch.io",
        "Piper",
        "GameMode",
        "Sunshine",
        "Moonlight",
        "OBS Studio",
        "Cartridges",
        "CoreCtrl",
        "Oversteer",
        "Greenlight",
    ),
    "Utveckling och teknik": (
        "Visual Studio Code",
        "KiCad",
        "Ansible",
        "Topgrade",
        "Chezmoi",
    ),
    "Paket och systemverktyg": (
        "Bauh",
        "Flatpak",
        "Snapcraft",
        "AppImageLauncher",
        "Warehouse",
        "GNOME Software",
        "KDE Discover",
        "Synaptic",
        "Pacstall",
        "Homebrew",
        "Nix",
        "Distrobox",
    ),
}
app_selections = {
    app_name: tk.BooleanVar(value=False)
    for category_apps in app_categories.values()
    for app_name in category_apps
}

tk.Label(
    app_content,
    text="Select apps to install or uninstall:",
    bg="white",
    font=("arial", 12, "bold"),
).pack(pady=(20, 10))

style = ttk.Style(root)
style.configure("Apps.TFrame", background="white")
tab_bar = tk.Frame(app_content, bg="white")
tab_bar.pack(fill="x", padx=24, pady=(0, 8))
category_content_area = tk.Frame(app_content, bg="white")
category_content_area.pack(fill="both", expand=True, padx=24, pady=8)
tab_font = ("arial", 9, "bold")


def create_app_option(parent, app_name, selected, index):
    option_frame = tk.Frame(parent, bg="#f3f3f3", padx=8, pady=6)
    option_frame.grid(
        row=index // 3,
        column=index % 3,
        sticky="ew",
        padx=6,
        pady=5,
    )
    indicator = tk.Canvas(
        option_frame,
        width=30,
        height=30,
        highlightthickness=0,
        takefocus=True,
        bg="#f3f3f3",
    )
    indicator.pack(side="left", padx=(0, 8))
    indicator.create_rectangle(
        3,
        3,
        27,
        27,
        outline="#777777",
        width=2,
        fill="#d9d9d9",
    )
    checkmark = indicator.create_line(
        8,
        15,
        13,
        20,
        22,
        10,
        fill="#222222",
        width=3,
        state="hidden",
    )
    app_label = tk.Label(
        option_frame,
        text=app_name,
        font=("arial", 9),
        bg="#f3f3f3",
        anchor="w",
    )
    app_label.pack(side="left")

    def toggle_selection(event=None):
        selected.set(not selected.get())

    indicator.bind("<Button-1>", toggle_selection)
    indicator.bind("<space>", toggle_selection)
    app_label.bind("<Button-1>", toggle_selection)
    selected.trace_add(
        "write",
        lambda *_args: indicator.itemconfigure(
            checkmark,
            state="normal" if selected.get() else "hidden",
        ),
    )


category_tabs = {}
category_pages = {}
for category_name, category_apps in app_categories.items():
    category_contents = ttk.Frame(
        category_content_area,
        style="Apps.TFrame",
        padding=16,
    )
    for column in range(3):
        category_contents.grid_columnconfigure(column, weight=1)
    for app_index, app_name in enumerate(category_apps):
        create_app_option(
            category_contents,
            app_name,
            app_selections[app_name],
            app_index,
        )
    category_pages[category_name] = category_contents
    category_tabs[category_name] = tk.Button(
        tab_bar,
        text=category_name,
        font=tab_font,
        padx=10,
        pady=8,
        justify="center",
        relief="flat",
        borderwidth=0,
        bg="#ededed",
        activebackground="#e2e2e2",
        command=lambda name=category_name: show_category(name),
    )


active_category = None


def show_category(category_name):
    global active_category
    if active_category is not None:
        category_pages[active_category].pack_forget()
    active_category = category_name
    category_pages[category_name].pack(fill="both", expand=True)
    for name, button in category_tabs.items():
        is_active = name == category_name
        button.configure(
            bg="#d9d9d9" if is_active else "#ededed",
            relief="sunken" if is_active else "flat",
        )


def arrange_category_tabs(_event=None):
    global tab_layout_job
    tab_layout_job = None
    available_width = tab_bar.winfo_width()
    if available_width <= 1:
        return

    spacing = 6
    column_count = min(
        len(category_tabs),
        max(1, min(4, available_width // 150)),
    )
    cell_width = (available_width - spacing * (column_count - 1)) // column_count
    for column in range(len(category_tabs)):
        tab_bar.grid_columnconfigure(column, weight=0, uniform="")

    for index, button in enumerate(category_tabs.values()):
        button.grid_forget()
        button.configure(wraplength=max(80, cell_width - 24))
        button.grid(
            row=index // column_count,
            column=index % column_count,
            sticky="ew",
            padx=spacing // 2,
            pady=3,
        )
    for column in range(column_count):
        tab_bar.grid_columnconfigure(
            column,
            weight=1,
            uniform="category-tabs",
        )


tab_layout_job = None


def schedule_category_tabs(_event=None):
    global tab_layout_job
    if tab_layout_job is None:
        tab_layout_job = root.after_idle(arrange_category_tabs)


tab_bar.bind("<Configure>", schedule_category_tabs)
show_category(next(iter(app_categories)))

status_frame = tk.Frame(app_content, bg="white")
status_frame.pack(fill="x", padx=24, pady=(6, 10))
status_text = tk.Text(
    status_frame,
    height=5,
    wrap="word",
    font=("arial", 10),
    fg="black",
    bg="#f8f8f8",
    relief="solid",
    borderwidth=1,
    state="disabled",
)
status_text.pack(fill="x", expand=True)

action_buttons = tk.Frame(app_content, bg="white")
action_buttons.pack(pady=(0, 10))
install_button = tk.Button(
    action_buttons,
    text="Install selected apps",
    command=install_selected_apps,
    bg="#d9d9d9",
    activebackground="#c8c8c8",
    relief="flat",
    padx=12,
    pady=6,
)
install_button.pack(side="left", padx=5)
uninstall_button = tk.Button(
    action_buttons,
    text="Uninstall selected apps",
    command=uninstall_selected_apps,
    bg="#d9d9d9",
    activebackground="#c8c8c8",
    relief="flat",
    padx=12,
    pady=6,
)
uninstall_button.pack(side="left", padx=5)
remove_app_button = tk.Button(
    app_content,
    text="Uninstall Deez Appz",
    command=uninstall_deez_app,
    bg="#f3e2e2",
    activebackground="#ebcccc",
    relief="flat",
    padx=12,
    pady=6,
)
remove_app_button.pack(pady=(0, 16))

root.mainloop()
