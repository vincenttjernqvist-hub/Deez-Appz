import json
import subprocess
import sys


APT_PACKAGES = {
    "Google Chrome": "google-chrome-stable",
    "Blender": "blender",
    "KiCad": "kicad",
    "Krita": "krita",
    "Flatpak": "flatpak",
    "GNOME Software": "gnome-software",
    "KDE Discover": "plasma-discover",
    "Synaptic": "synaptic",
    "Nix": "nix-bin",
    "Distrobox": "distrobox",
    "Ansible": "ansible",
    "VLC": "vlc",
    "LibreOffice": "libreoffice",
    "MangoHud": "mangohud",
    "GameMode": "gamemode",
    "OBS Studio": "obs-studio",
    "GIMP": "gimp",
    "Flameshot": "flameshot",
    "Transmission": "transmission-gtk",
    "CoreCtrl": "corectrl",
    "AppImageLauncher": "appimagelauncher",
}
SNAP_PACKAGES = {
    "Visual Studio Code": ("code", "--classic"),
    "Spotify": ("spotify",),
    "Brave": ("brave",),
    "Discord": ("discord",),
    "Snapcraft": ("snapcraft", "--classic"),
    "Chezmoi": ("chezmoi", "--classic"),
    "Firefox": ("firefox",),
    "Telegram": ("telegram-desktop",),
    "Thunderbird": ("thunderbird",),
}
FLATPAK_APPS = {
    "Warehouse": "io.github.flattool.Warehouse",
    "OnlyOffice": "org.onlyoffice.desktopeditors",
    "Bitwarden": "com.bitwarden.desktop",
    "Obsidian": "md.obsidian.Obsidian",
    "Element": "im.riot.Riot",
    "Slack": "com.slack.Slack",
    "Microsoft Teams": "com.github.IsmaelMartinez.teams_for_linux",
    "Session": "network.loki.Session",
    "Mumble": "info.mumble.Mumble",
    "TeamSpeak": "com.teamspeak.TeamSpeak",
    "Caprine": "com.sindresorhus.Caprine",
    "Fractal": "org.gnome.Fractal",
    "FluffyChat": "im.fluffychat.Fluffychat",
    "Zoom": "us.zoom.Zoom",
    "Mattermost": "com.mattermost.Desktop",
    "Zulip": "org.zulip.Zulip",
    "SimpleX Chat": "chat.simplex.simplex",
    "qTox": "io.github.qtox.qTox",
    "Signal": "org.signal.Signal",
    "Steam": "com.valvesoftware.Steam",
    "Lutris": "net.lutris.Lutris",
    "Heroic Games Launcher": "com.heroicgameslauncher.hgl",
    "ProtonUp-Qt": "net.davidotek.pupgui2",
    "Goverlay": "io.github.benjamimgois.goverlay",
    "Bottles": "com.usebottles.bottles",
    "Prism Launcher": "org.prismlauncher.PrismLauncher",
    "RetroArch": "org.libretro.RetroArch",
    "Itch.io": "io.itch.itch",
    "Piper": "org.freedesktop.Piper",
    "Sunshine": "dev.lizardbyte.app.Sunshine",
    "Moonlight": "com.moonlight_stream.Moonlight",
    "Cartridges": "page.kramo.Cartridges",
    "Oversteer": "io.github.berarma.Oversteer",
    "Greenlight": "io.github.unknownskl.greenlight",
    "Heroic Games Launcher": "com.heroicgameslauncher.hgl",
}
UNAVAILABLE_APPS = {
    "Revolt": "No verified Linux package is configured.",
    "Skype": "The Flathub package is marked end-of-life.",
    "Threema": "No verified Linux desktop package is configured.",
    "Wire": "No verified Linux desktop package is configured.",
    "Guilded": "No verified Linux desktop package is configured.",
    "Jitsi Meet": "No verified Linux desktop package is configured.",
}
MANUAL_INSTALL_APPS = {
    "Google Chrome",
    "Bauh",
    "Topgrade",
    "Pacstall",
    "Homebrew",
}


def run_install(app_names, manual_install_data=None):
    manual_install_data = manual_install_data or {}
    manual_paths = manual_install_data.get("paths", {})
    progress_total = int(manual_install_data.get("progress_total", len(app_names)))
    completed_apps = set()

    def emit_progress(event, **details):
        print(
            "DEEZ_PROGRESS " + json.dumps({
                "event": event,
                "completed": len(completed_apps),
                "total": progress_total,
                **details,
            }),
            file=sys.stderr,
            flush=True,
        )

    def complete_app(app_name):
        if app_name not in completed_apps:
            completed_apps.add(app_name)
            emit_progress("app_complete", app=app_name)

    emit_progress("started")
    maintenance_results = {}
    unknown_apps = set(app_names) - (
        set(APT_PACKAGES)
        | set(SNAP_PACKAGES)
        | set(FLATPAK_APPS)
        | set(UNAVAILABLE_APPS)
        | MANUAL_INSTALL_APPS
    )
    if unknown_apps:
        raise ValueError(f"Unsupported apps: {', '.join(sorted(unknown_apps))}")

    if manual_install_data.get("remove_deprecated_appimagelauncher_ppa"):
        try:
            ppa_check = subprocess.run(
                [
                    "grep",
                    "-R",
                    "-l",
                    "-F",
                    "appimagelauncher-team/stable",
                    "/etc/apt/sources.list.d",
                ],
                check=False,
                capture_output=True,
                text=True,
            )
            if ppa_check.returncode == 0:
                subprocess.run(
                    [
                        "add-apt-repository",
                        "--remove",
                        "--yes",
                        "ppa:appimagelauncher-team/stable",
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
                maintenance_results["appimagelauncher_ppa"] = "removed"
            elif ppa_check.returncode != 1:
                raise subprocess.CalledProcessError(
                    ppa_check.returncode,
                    ppa_check.args,
                    stderr=ppa_check.stderr,
                )
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            maintenance_results["appimagelauncher_ppa"] = (
                f"could not remove deprecated source ({detail.strip()})"
            )

    results = {
        name: UNAVAILABLE_APPS[name]
        for name in app_names
        if name in UNAVAILABLE_APPS
    }
    for name in results:
        complete_app(name)
    apt_apps = [name for name in app_names if name in APT_PACKAGES]
    if any(name in FLATPAK_APPS for name in app_names) and "Flatpak" not in apt_apps:
        apt_apps.append("Flatpak")

    apt_packages = [
        APT_PACKAGES[name] for name in apt_apps
    ]
    apt_app_names = list(apt_apps)

    manual_apt_packages = {
        "Bauh": ["pipx", "python3-gi", "gir1.2-gtk-3.0"],
        "Topgrade": ["cargo"],
        "Homebrew": ["build-essential", "procps", "curl", "file", "git"],
    }
    for name, packages in manual_apt_packages.items():
        if name in app_names:
            apt_app_names.append(name)
            apt_packages.extend(packages)

    if "Google Chrome" in app_names:
        chrome_package = manual_paths.get("google_chrome_deb")
        if chrome_package:
            apt_app_names.append("Google Chrome")
            apt_packages.append(chrome_package)
        else:
            results["Google Chrome"] = "installation failed (downloaded package is missing)"

    if "Piper" in app_names:
        apt_packages.append("ratbagd")

    if apt_packages:
        emit_progress("phase", message="Installing system packages")
        try:
            apt_command = [
                "apt-get",
                "install",
                "-y",
                "-o",
                "APT::Status-Fd=1",
                *apt_packages,
            ]
            apt_process = subprocess.Popen(
                apt_command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            apt_output = []
            for line in apt_process.stdout:
                if line.startswith("pmstatus:"):
                    status_parts = line.rstrip().split(":", 3)
                    if len(status_parts) >= 3:
                        try:
                            package_percentage = float(status_parts[2])
                        except ValueError:
                            continue
                        emit_progress(
                            "batch_progress",
                            percent=package_percentage,
                            stage="install",
                            batch_count=len(apt_app_names),
                            message=(
                                status_parts[3]
                                if len(status_parts) > 3
                                else "Installing system packages"
                            ),
                        )
                elif line.startswith("dlstatus:"):
                    status_parts = line.rstrip().split(":")
                    if len(status_parts) >= 7:
                        try:
                            download_percentage = float(status_parts[-3])
                        except ValueError:
                            continue
                        emit_progress(
                            "batch_download",
                            percent=download_percentage,
                            stage="download",
                            batch_count=len(apt_app_names),
                            message=status_parts[-4] or "Downloading system packages",
                        )
                else:
                    apt_output.append(line)
            apt_returncode = apt_process.wait()
            if apt_returncode:
                raise subprocess.CalledProcessError(
                    apt_returncode,
                    apt_command,
                    output="".join(apt_output),
                )
            for name in apt_app_names:
                results[name] = (
                    "ready for user setup"
                    if name in {"Bauh", "Topgrade", "Homebrew"}
                    else "installed"
                )
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            for name in apt_app_names:
                results[name] = f"installation failed ({detail.strip()})"
            if "Piper" in app_names:
                results["Piper"] = (
                    "installation failed: could not install ratbagd "
                    f"dependency ({detail.strip()})"
                )
        for name in apt_app_names:
            if name not in {"Bauh", "Topgrade", "Homebrew"}:
                complete_app(name)
    if "Homebrew" in app_names and results.get("Homebrew") == "ready for user setup":
        try:
            subprocess.run(
                [
                    "install",
                    "-d",
                    "-o",
                    str(manual_install_data["uid"]),
                    "-g",
                    str(manual_install_data["gid"]),
                    "/home/linuxbrew/.linuxbrew",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
        except (KeyError, OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            results["Homebrew"] = f"installation failed ({detail.strip()})"

    if "Pacstall" in app_names:
        emit_progress("phase", message="Installing Pacstall")
        installer_path = manual_paths.get("pacstall_installer")
        if installer_path:
            try:
                subprocess.run(
                    ["bash", installer_path],
                    check=True,
                    capture_output=True,
                    text=True,
                    input="n\n",
                )
                results["Pacstall"] = "installed"
            except (OSError, subprocess.CalledProcessError) as error:
                detail = getattr(error, "stderr", None) or str(error)
                results["Pacstall"] = f"installation failed ({detail.strip()})"
        else:
            results["Pacstall"] = "installation failed (installer file is missing)"
        complete_app("Pacstall")

    snap_apps = [name for name in app_names if name in SNAP_PACKAGES]
    for name in snap_apps:
        emit_progress("phase", message=f"Installing {name}")
        try:
            subprocess.run(
                ["snap", "install", *SNAP_PACKAGES[name]],
                check=True,
                capture_output=True,
                text=True,
            )
            results[name] = "installed"
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            results[name] = f"installation failed ({detail.strip()})"
        complete_app(name)

    flatpak_apps = [name for name in app_names if name in FLATPAK_APPS]
    if flatpak_apps:
        emit_progress("phase", message="Preparing Flathub")
        try:
            subprocess.run(
                [
                    "flatpak",
                    "remote-add",
                    "--system",
                    "--if-not-exists",
                    "flathub",
                    "https://flathub.org/repo/flathub.flatpakrepo",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            for name in flatpak_apps:
                if name in results:
                    continue
                results[name] = (
                    f"installation failed: could not configure Flathub "
                    f"({detail.strip()})"
                )
                complete_app(name)
        else:
            for name in flatpak_apps:
                if name in results:
                    continue
                emit_progress("phase", message=f"Installing {name}")
                try:
                    subprocess.run(
                        [
                            "flatpak",
                            "install",
                            "--system",
                            "--assumeyes",
                            "flathub",
                            FLATPAK_APPS[name],
                        ],
                        check=True,
                        capture_output=True,
                        text=True,
                    )
                    results[name] = (
                        "installed with ratbagd" if name == "Piper"
                        else "installed"
                    )
                    if name == "Sunshine":
                        try:
                            subprocess.run(
                                [
                                    "flatpak",
                                    "run",
                                    "--command=additional-install.sh",
                                    FLATPAK_APPS[name],
                                ],
                                check=True,
                                capture_output=True,
                                text=True,
                            )
                        except (OSError, subprocess.CalledProcessError) as error:
                            detail = getattr(error, "stderr", None) or str(error)
                            results[name] = (
                                "installed, but additional setup failed "
                                f"({detail.strip()})"
                            )
                except (OSError, subprocess.CalledProcessError) as error:
                    detail = getattr(error, "stderr", None) or str(error)
                    results[name] = f"installation failed ({detail.strip()})"
                complete_app(name)

    for name in app_names:
        if name not in {"Bauh", "Topgrade", "Homebrew"}:
            complete_app(name)

    output = {
        name: results.get(name, "installation failed (no result returned)")
        for name in app_names
    }
    if maintenance_results:
        output["__maintenance__"] = maintenance_results
    print(json.dumps(output))


def run_uninstall(app_names):
    results = {}
    apt_apps = [name for name in app_names if name in APT_PACKAGES]
    snap_apps = [name for name in app_names if name in SNAP_PACKAGES]
    flatpak_apps = [name for name in app_names if name in FLATPAK_APPS]
    unsupported_apps = set(app_names) - (
        set(APT_PACKAGES) | set(SNAP_PACKAGES) | set(FLATPAK_APPS)
    )
    for name in unsupported_apps:
        results[name] = "no automatic system uninstaller is configured"

    if apt_apps:
        packages = [APT_PACKAGES[name] for name in apt_apps]
        try:
            subprocess.run(
                ["apt-get", "remove", "-y", *packages],
                check=True,
                capture_output=True,
                text=True,
            )
            results.update({name: "uninstalled" for name in apt_apps})
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            results.update({
                name: f"uninstallation failed ({detail.strip()})"
                for name in apt_apps
            })

    for name in snap_apps:
        try:
            subprocess.run(
                ["snap", "remove", SNAP_PACKAGES[name][0]],
                check=True,
                capture_output=True,
                text=True,
            )
            results[name] = "uninstalled"
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            results[name] = f"uninstallation failed ({detail.strip()})"

    for name in flatpak_apps:
        try:
            subprocess.run(
                [
                    "flatpak",
                    "uninstall",
                    "--system",
                    "--assumeyes",
                    FLATPAK_APPS[name],
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            results[name] = "uninstalled"
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "stderr", None) or str(error)
            results[name] = f"uninstallation failed ({detail.strip()})"

    print(json.dumps({
        name: results.get(name, "uninstallation failed (no result returned)")
        for name in app_names
    }))


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--request-file":
        with open(sys.argv[2], encoding="utf-8") as request_file:
            request = json.load(request_file)
        run_install(request["apps"], request.get("manual_install_data"))
    elif len(sys.argv) == 3 and sys.argv[1] == "--uninstall-request-file":
        with open(sys.argv[2], encoding="utf-8") as request_file:
            request = json.load(request_file)
        run_uninstall(request["apps"])
    else:
        run_install(sys.argv[1:])
