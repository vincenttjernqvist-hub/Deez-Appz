import importlib.util
import math
import os
import pwd
import shutil
import subprocess
import sys
import tempfile
import urllib.request

if importlib.util.find_spec("tkinter") is None:
    if shutil.which("apt-get") is None:
        sys.exit("Tkinter is missing and this system does not use Ubuntu's package manager.")

    print("Tkinter is missing. Installing it...")
    subprocess.run(["pkexec", "apt-get", "update"], check=True)
    subprocess.run(
        ["pkexec", "apt-get", "install", "-y", "python3-tk"],
        check=True
    )

import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("Deez Appz")
root.geometry("1000x760")
root.configure(bg="white")


def build_app_icon():
    icon = tk.PhotoImage(width=64, height=64)

    def set_pixel(x, y, color):
        if 0 <= x < 64 and 0 <= y < 64:
            icon.put(color, (x, y))

    def fill_circle(cx, cy, r, color):
        for y in range(max(0, cy - r), min(64, cy + r + 1)):
            for x in range(max(0, cx - r), min(64, cx + r + 1)):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                    set_pixel(x, y, color)

    def draw_ring(cx, cy, outer_r, inner_r, color):
        fill_circle(cx, cy, outer_r, color)
        fill_circle(cx, cy, inner_r, "#1c4f7d")

    def draw_tooth(cx, cy, radius, angle_deg, length=8, width=5, color="#2d9bd3"):
        angle = math.radians(angle_deg)
        for step in range(length):
            tx = int(round(cx + math.cos(angle) * (radius + step)))
            ty = int(round(cy + math.sin(angle) * (radius + step)))
            for dx in range(-width, width + 1):
                for dy in range(-width, width + 1):
                    if dx * dx + dy * dy <= width * width:
                        set_pixel(tx + dx, ty + dy, color)

    def fill_polygon(points, color):
        min_x = min(p[0] for p in points)
        max_x = max(p[0] for p in points)
        min_y = min(p[1] for p in points)
        max_y = max(p[1] for p in points)

        for y in range(max(0, min_y), min(64, max_y + 1)):
            for x in range(max(0, min_x), min(64, max_x + 1)):
                inside = False
                for index, point in enumerate(points):
                    x1, y1 = point
                    x2, y2 = points[(index + 1) % len(points)]
                    intersects = ((y1 > y) != (y2 > y)) and (
                        x < (x2 - x1) * (y - y1) / (y2 - y1) + x1
                    )
                    if intersects:
                        inside = not inside
                if inside:
                    set_pixel(x, y, color)

    for y in range(64):
        for x in range(64):
            dx = x - 32
            dy = y - 32
            if abs(dx) < 30 and abs(dy) < 30:
                r = min(1.0, 1.0 - (abs(dx) + abs(dy)) / 80)
                c1 = (22, 90, 148)
                c2 = (54, 191, 216)
                r1, g1, b1 = c1
                r2, g2, b2 = c2
                red = int(r1 + (r2 - r1) * (1 - (abs(dx) + abs(dy)) / 80))
                green = int(g1 + (g2 - g1) * (1 - (abs(dx) + abs(dy)) / 80))
                blue = int(b1 + (b2 - b1) * (1 - (abs(dx) + abs(dy)) / 80))
                icon.put(f'#{red:02x}{green:02x}{blue:02x}', (x, y))
            else:
                icon.put("#0b3a6d", (x, y))

    draw_ring(32, 32, 24, 12, "#4ec9d1")
    draw_ring(32, 32, 20, 14, "#1d5d8a")
    for angle in range(0, 360, 30):
        draw_tooth(32, 32, 24, angle, 8, 4, "#5fc7e8")

    fill_circle(32, 32, 8, "#2f9ad1")

    shaft_color = "#d7f4ff"
    fill_circle(32, 32, 4, shaft_color)

    arrow_points = [
        (32, 18),
        (22, 36),
        (28, 36),
        (28, 52),
        (36, 52),
        (36, 36),
        (42, 36),
    ]
    fill_polygon(arrow_points, "#a8f3ff")
    fill_polygon([(32, 18), (29, 12), (35, 12)], "#c9fbff")

    for x in range(8, 57):
        for y in range(58, 64):
            if (x - 32) ** 2 + (y - 61) ** 2 <= 7 ** 2:
                icon.put("#dffbff", (x, y))

    return icon


app_icon = build_app_icon()
root.iconphoto(True, app_icon)


def install_selected_apps():
    selected_apps = [
        app_name for app_name, selected in app_selections.items()
        if selected.get()
    ]
    if not selected_apps:
        label.config(text="Select at least one app to install.")
        return

    def install_google_chrome():
        with tempfile.TemporaryDirectory() as temp_dir:
            package_path = os.path.join(temp_dir, "google-chrome.deb")
            with urllib.request.urlopen(
                "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb",
                timeout=60,
            ) as response, open(package_path, "wb") as package:
                shutil.copyfileobj(response, package)
            subprocess.run(
                ["pkexec", "apt-get", "install", "-y", package_path],
                check=True,
            )

    def install_pacstall():
        with tempfile.TemporaryDirectory() as temp_dir:
            installer_path = os.path.join(temp_dir, "pacstall-installer")
            with urllib.request.urlopen(
                "https://pacstall.dev/q/pacstall",
                timeout=60,
            ) as response, open(installer_path, "wb") as installer:
                shutil.copyfileobj(response, installer)
            subprocess.run(["pkexec", "bash", installer_path], check=True)

    def install_bauh():
        subprocess.run(
            [
                "pkexec",
                "apt-get",
                "install",
                "-y",
                "pipx",
                "python3-gi",
                "gir1.2-gtk-3.0",
            ],
            check=True,
        )
        subprocess.run(
            ["pipx", "install", "--system-site-packages", "bauh"],
            check=True,
        )

    def install_topgrade():
        subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "cargo"],
            check=True,
        )
        subprocess.run(["cargo", "install", "--locked", "topgrade"], check=True)

    def install_flatpak_app(app_id):
        subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "flatpak"],
            check=True,
        )
        subprocess.run(
            [
                "pkexec",
                "flatpak",
                "remote-add",
                "--system",
                "--if-not-exists",
                "flathub",
                "https://flathub.org/repo/flathub.flatpakrepo",
            ],
            check=True,
        )
        subprocess.run(
            [
                "pkexec",
                "flatpak",
                "install",
                "--system",
                "--assumeyes",
                "flathub",
                app_id,
            ],
            check=True,
        )

    def install_appimagelauncher():
        subprocess.run(
            [
                "pkexec",
                "apt-get",
                "install",
                "-y",
                "software-properties-common",
            ],
            check=True,
        )
        subprocess.run(
            [
                "pkexec",
                "add-apt-repository",
                "-y",
                "ppa:appimagelauncher-team/stable",
            ],
            check=True,
        )
        subprocess.run(["pkexec", "apt-get", "update"], check=True)
        subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "appimagelauncher"],
            check=True,
        )

    def install_homebrew():
        subprocess.run(
            [
                "pkexec",
                "apt-get",
                "install",
                "-y",
                "build-essential",
                "procps",
                "curl",
                "file",
                "git",
            ],
            check=True,
        )
        user = pwd.getpwuid(os.getuid())
        subprocess.run(
            [
                "pkexec",
                "install",
                "-d",
                "-o",
                str(user.pw_uid),
                "-g",
                str(user.pw_gid),
                "/home/linuxbrew/.linuxbrew",
            ],
            check=True,
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            installer_path = os.path.join(temp_dir, "homebrew-installer")
            with urllib.request.urlopen(
                "https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh",
                timeout=60,
            ) as response, open(installer_path, "wb") as installer:
                shutil.copyfileobj(response, installer)
            subprocess.run(
                ["/bin/bash", installer_path],
                check=True,
                env={**os.environ, "NONINTERACTIVE": "1"},
            )

    installers = {
        "Visual Studio Code": lambda: subprocess.run(
            ["pkexec", "snap", "install", "code", "--classic"], check=True
        ),
        "Spotify": lambda: subprocess.run(
            ["pkexec", "snap", "install", "spotify"], check=True
        ),
        "Blender": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "blender"], check=True
        ),
        "KiCad": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "kicad"], check=True
        ),
        "Krita": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "krita"], check=True
        ),
        "Google Chrome": install_google_chrome,
        "Brave": lambda: subprocess.run(
            ["pkexec", "snap", "install", "brave"], check=True
        ),
        "Discord": lambda: subprocess.run(
            ["pkexec", "snap", "install", "discord"], check=True
        ),
        "Bauh": install_bauh,
        "Topgrade": install_topgrade,
        "Flatpak": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "flatpak"], check=True
        ),
        "Snapcraft": lambda: subprocess.run(
            ["pkexec", "snap", "install", "snapcraft", "--classic"], check=True
        ),
        "AppImageLauncher": install_appimagelauncher,
        "Warehouse": lambda: install_flatpak_app("io.github.flattool.Warehouse"),
        "GNOME Software": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "gnome-software"], check=True
        ),
        "KDE Discover": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "plasma-discover"], check=True
        ),
        "Synaptic": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "synaptic"], check=True
        ),
        "Pacstall": install_pacstall,
        "Homebrew": install_homebrew,
        "Nix": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "nix-bin"], check=True
        ),
        "Distrobox": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "distrobox"], check=True
        ),
        "Chezmoi": lambda: subprocess.run(
            ["pkexec", "snap", "install", "chezmoi"], check=True
        ),
        "Ansible": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "ansible"], check=True
        ),
        "VLC": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "vlc"], check=True
        ),
        "Firefox": lambda: subprocess.run(
            ["pkexec", "snap", "install", "firefox"], check=True
        ),
        "LibreOffice": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "libreoffice"], check=True
        ),
        "OnlyOffice": lambda: install_flatpak_app(
            "org.onlyoffice.desktopeditors"
        ),
        "Bitwarden": lambda: install_flatpak_app("com.bitwarden.desktop"),
        "Telegram": lambda: subprocess.run(
            ["pkexec", "snap", "install", "telegram-desktop"], check=True
        ),
        "Signal": lambda: install_flatpak_app("org.signal.Signal"),
        "Steam": lambda: install_flatpak_app("com.valvesoftware.Steam"),
        "OBS Studio": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "obs-studio"], check=True
        ),
        "GIMP": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "gimp"], check=True
        ),
        "Obsidian": lambda: install_flatpak_app("md.obsidian.Obsidian"),
        "Flameshot": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "flameshot"], check=True
        ),
        "Thunderbird": lambda: subprocess.run(
            ["pkexec", "snap", "install", "thunderbird"], check=True
        ),
        "Transmission": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "transmission-gtk"], check=True
        ),
        "Lutris": lambda: subprocess.run(
            ["pkexec", "apt-get", "install", "-y", "lutris"], check=True
        ),
        "Heroic Games Launcher": lambda: install_flatpak_app(
            "com.heroicgameslauncher.hgl"
        ),
    }
    results = []

    for app_name in selected_apps:
        label.config(text=f"Installing {app_name}...")
        root.update_idletasks()
        try:
            installers[app_name]()
            results.append(f"{app_name}: installed")
        except (OSError, subprocess.CalledProcessError) as error:
            results.append(f"{app_name}: installation failed ({error})")

    label.config(text="\n".join(results))

app_categories = {
    "Webb och internet": (
        "Google Chrome",
        "Brave",
        "Firefox",
        "Thunderbird",
        "Transmission",
    ),
    "Kontor och produktivitet": (
        "LibreOffice",
        "OnlyOffice",
        "Obsidian",
        "Bitwarden",
    ),
    "Kommunikation": (
        "Discord",
        "Telegram",
        "Signal",
    ),
    "Media och kreativt": (
        "Spotify",
        "VLC",
        "OBS Studio",
        "GIMP",
        "Krita",
        "Blender",
        "Flameshot",
    ),
    "Spel": (
        "Steam",
        "Lutris",
        "Heroic Games Launcher",
    ),
    "Utveckling och teknik": (
        "Visual Studio Code",
        "KiCad",
        "Ansible",
        "Topgrade",
        "Chezmoi",
    ),
    "Paket och systemverktyg": (
        "Bauh",
        "Flatpak",
        "Snapcraft",
        "AppImageLauncher",
        "Warehouse",
        "GNOME Software",
        "KDE Discover",
        "Synaptic",
        "Pacstall",
        "Homebrew",
        "Nix",
        "Distrobox",
    ),
}
app_selections = {
    app_name: tk.BooleanVar(value=False)
    for category_apps in app_categories.values()
    for app_name in category_apps
}

tk.Label(
    root,
    text="Select the apps you want to install:",
    bg="white",
    font=("arial", 12, "bold"),
).pack(pady=(20, 10))

style = ttk.Style(root)
style.configure("TNotebook", background="white", borderwidth=0)
style.configure(
    "Category.TFrame",
    background="white",
)
style.configure("Apps.TFrame", background="white")
tab_bar = tk.Frame(root, bg="white")
tab_bar.pack(fill="x", padx=24, pady=(0, 8))
category_content_area = tk.Frame(root, bg="white")
category_content_area.pack(fill="both", expand=True, padx=24, pady=8)
tab_font = ("arial", 9, "bold")


def create_app_option(parent, app_name, selected, index):
    option_frame = tk.Frame(parent, bg="#f3f3f3", padx=8, pady=6)
    option_frame.grid(
        row=index // 3,
        column=index % 3,
        sticky="ew",
        padx=6,
        pady=5,
    )
    indicator = tk.Canvas(
        option_frame,
        width=30,
        height=30,
        highlightthickness=0,
        takefocus=True,
        bg="#f3f3f3",
    )
    indicator.pack(side="left", padx=(0, 8))
    indicator.create_rectangle(
        3,
        3,
        27,
        27,
        outline="#777777",
        width=2,
        fill="#d9d9d9",
    )
    checkmark = indicator.create_line(
        8,
        15,
        13,
        20,
        22,
        10,
        fill="#222222",
        width=3,
        state="hidden",
    )
    app_label = tk.Label(
        option_frame,
        text=app_name,
        font=("arial", 9),
        bg="#f3f3f3",
        anchor="w",
    )
    app_label.pack(side="left")

    def toggle_selection(event=None):
        selected.set(not selected.get())

    indicator.bind("<Button-1>", toggle_selection)
    indicator.bind("<space>", toggle_selection)
    app_label.bind("<Button-1>", toggle_selection)
    selected.trace_add(
        "write",
        lambda *_args: indicator.itemconfigure(
            checkmark,
            state="normal" if selected.get() else "hidden",
        ),
    )


category_tabs = {}
category_pages = {}
for category_name, category_apps in app_categories.items():
    category_contents = ttk.Frame(
        category_content_area,
        style="Apps.TFrame",
        padding=16,
    )
    for column in range(3):
        category_contents.grid_columnconfigure(column, weight=1)
    for app_index, app_name in enumerate(category_apps):
        create_app_option(
            category_contents,
            app_name,
            app_selections[app_name],
            app_index,
        )
    category_pages[category_name] = category_contents
    category_tabs[category_name] = tk.Button(
        tab_bar,
        text=category_name,
        font=tab_font,
        padx=10,
        pady=8,
        relief="flat",
        borderwidth=0,
        bg="#ededed",
        activebackground="#e2e2e2",
        command=lambda name=category_name: show_category(name),
    )


active_category = None


def show_category(category_name):
    global active_category
    if active_category is not None:
        category_pages[active_category].pack_forget()
    active_category = category_name
    category_pages[category_name].pack(fill="both", expand=True)
    for name, button in category_tabs.items():
        is_active = name == category_name
        button.configure(
            bg="#d9d9d9" if is_active else "#ededed",
            relief="sunken" if is_active else "flat",
        )


def arrange_category_tabs(_event=None):
    available_width = tab_bar.winfo_width()
    if available_width <= 1:
        return

    current_row = 0
    current_column = 0
    row_width = 0
    for button in category_tabs.values():
        button.grid_forget()
        button_width = button.winfo_reqwidth()
        if current_column and row_width + button_width > available_width:
            current_row += 1
            current_column = 0
            row_width = 0
        button.grid(row=current_row, column=current_column, sticky="w", padx=(0, 6), pady=3)
        row_width += button_width + 6
        current_column += 1


tab_bar.bind("<Configure>", arrange_category_tabs)
show_category(next(iter(app_categories)))

label = tk.Label(
    root,
    text="",
    font=("arial", 10),
    fg="black",
    bg="white",
    wraplength=700,
)
label.pack(pady=24)

button = tk.Button(
    root,
    text="Install selected apps",
    command=install_selected_apps,
    bg="#d9d9d9",
    activebackground="#c8c8c8",
    relief="flat",
    padx=12,
    pady=6,
)
button.pack()

root.mainloop()
